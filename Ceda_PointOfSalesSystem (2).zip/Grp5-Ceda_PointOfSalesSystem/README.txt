CEDA Auto Supply Point of Sale System (POS) with GUI and Database

== PROJECT DESCRIPTION ==
	This Point-of-Sale (POS) system is designed for small local shop businesses around the Philippines. The system focuses more on the daily transactions of each customer from the staff with a provided sales report to the admin. It also allows management of products with specific details and can generate receipts throughout the system.  The goal for this system was to checkout the process of orders, keep track of products and sales records. 

== GROUP MEMBERS ==
De Armas, Archie S.
Gonzalez, Rheanna V. 
Manzano, Elohim Lee
Ortega, Amirah L. 
Umali, Jhayner D. 


== FEATURES & FUNCTIONALITIES ==
This system provides a good features including:
*Product Management
*Sales Processing
*CRUD Operators (only for admin) 
*Receipt Generator
*Sales Report
*User authentication/login
*GUI-based interface using Java Swing

== TECHNOLOGIES USED ==
• Java (JDK 22)
• JavaFXfor GUI
• SQL Server Management Studio 20  for database management
• JDBC 12.4.2 for database connectivity
• NetBeans/IntelliJ IDEA as the IDE
PDF
• itext7 core 7.1.17 
• slf4j api 1.7.36


== INSTALLATION & SETUP INSTRUCTIONS ==
1. Install JDK 11 or higher.
2. Install MySQL and create the database using the provided SQL file.
3. Open the project in NetBeans or IntelliJ IDEA.
4. If you’re using maven, make sure to add the 	‘dependencies’ on pom.xml in project
4. Run the `MainLogin.java` file to start the system.
== If you’re using maven, add these code: ==
<dependency>
   <groupId>com.itextpdf</groupId>
   <artifactId>kernel</artifactId>
   <version>8.0.3</version>
</dependency>

<dependency>
   <groupId>com.itextpdf</groupId>
   <artifactId>layout</artifactId>
   <version>8.0.3</version>
</dependency>

<dependency>
   <groupId>com.itextpdf</groupId>
   <artifactId>io</artifactId>
   <version>8.0.3</version>
</dependency>
<dependency>
   <groupId>com.microsoft.sqlserver</groupId>
   <artifactId>mssql-jdbc</artifactId>
   <version>12.10.0.jre11</version>
</dependency>
<dependency>
   <groupId>com.microsoft.sqlserver</groupId>
   <artifactId>mssql-jdbc_auth</artifactId>
   <version>12.10.0.x64</version>
</dependency>
<dependency>
<dependency>
   <groupId>com.itextpdf</groupId>
   <artifactId>itextpdf</artifactId>
   <version>5.5.13.3</version>
</dependency>

== DATABASECONFIGURATION ==

Table Structures:
1. Employee_Type
Employee_Type – VARCHAR(50) – Primary Key. Type of employee (e.g., Full Time)

Rate – DECIMAL(10,2) – Daily rate for the employee type

2. Employee
EmployeeID – INT – Primary Key, Identity. Unique ID for each employee

First_Name – VARCHAR(50)

Middle_Name – VARCHAR(50)

Last_Name – VARCHAR(50)

Sex – CHAR(1) – (M/F)

Hire_Date – DATE

Employee_Type – VARCHAR(50) – Foreign Key to Employee_Type

ROLE – VARCHAR(20) – (Admin or Staff)

Password – VARCHAR(50)

Status – VARCHAR(10) – (Active or Inactive)

3. Category
CategoryID – INT – Primary Key, Identity

CategoryName – VARCHAR(50)

Description – TEXT

4. Product
ProductID – INT – Primary Key, Identity

Product_Description – TEXT

Product_Quantity – INT

Product_Price – DECIMAL(10,2)

OEIMD – VARCHAR(50) – Original Equipment Manufacturer or Model Info

Reorder_Level – INT

Last_Restock_Date – DATE

5. Orders
OrderID – INT – Primary Key, Identity

Order_Date – DATE

Description – TEXT

Status – VARCHAR(10) – (Completed, Pending, etc.)

EmployeeID – INT – Foreign Key to Employee

6. Payment
PaymentID – INT – Primary Key, Identity

OrderID – INT – Foreign Key to Orders

Transaction_Date – DATE

Amount_Paid – DECIMAL(10,2)

Payment_Status – VARCHAR(50) – (Paid, Unpaid, etc.)




== USAGE GUIDE ==
*Login: Please enter first the provided username and password for admin and staffs
**For Admin:**
**user id: 10 password: admin**
**For Staff:**
**user id: 12 password: staff**

*Dashboard: only admin have a dashboard. The staffs once log in, the POS will automatically provide
*Sales: Only admin can view sales, the process of the sales are if the transactions of the staff adds orders.
*Reports: Reports are also based into the sales that you can export and print the file
*Transaction: transaction works in the processing staffs and admin



== KNOWN ISSUES & FUTURE ENHANCEMENTS==
== Issues: ==
*Always check your files before running. Files like maven MUST have an dependencies which it was stated onto the guides
*Always check the database before running the system. Never miss all the files included there


== Future Enhancements:==

*Better GUI for the users
*Barcode scanner integration for future processes
*Cloud-based database support
*Enhancement of roles (staff and admin)
*More efficient sales record
*Inventory for supplies


== ACKNOWLEDGEMENTS & REFERENCES ==
Based on https://www.youtube.com/watch?v=ZlpGjWMRtBc&t=24s
Based on https://www.youtube.com/watch?v=FLkOX4Eez6o&list=PL6gx4Cwl9DGBzfXLWLSYVy8EbTdpGbUIG

