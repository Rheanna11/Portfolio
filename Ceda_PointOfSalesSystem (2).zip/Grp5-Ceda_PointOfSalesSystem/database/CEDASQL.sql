--COMMENTS (NEED I-EXECUTE PO)--
--need i-execute creation, insert alter query
--1st: creare tables.
--2nd: execute tje insertion 


--needed to be executed
create database CEDA
use CEDA

--creation of table. NEED I-EXECUTE PO ALL
CREATE TABLE Employee_Type (
    Employee_Type VARCHAR(50) PRIMARY KEY,
    Rate DECIMAL(10, 2)
);

INSERT INTO Employee_Type VALUES ('Full Time', '800.00')

CREATE TABLE  Employee (
    EmployeeID INT PRIMARY KEY identity (1,1),
    First_Name VARCHAR(50),
    Middle_Name VARCHAR(50),
    Last_Name VARCHAR(50),
    Sex CHAR(1),
    Hire_Date DATE,
    Employee_Type VARCHAR(50),
	ROLE VARCHAR(20) NOT NULL CHECK(ROLE IN ('Admin', 'Staff')),
	Password VARCHAR (50),
    Status VARCHAR(10) CHECK (Status IN ('Active', 'Inactive')),
    FOREIGN KEY (Employee_Type) REFERENCES Employee_Type(Employee_Type)
);


INSERT INTO Employee 
VALUES ('Jhayner', 'D.', 'Umali', 'M', '2023-1-5', 'Full Time', 'Admin', 'admin', 'Active'),
('Lee', 'L.', 'Manzano', 'M', '2023-1-5', 'Full Time', 'Staff', 'staff', 'Active');

SELECT * FROM Employee

CREATE TABLE Product (
    ProductID INT PRIMARY KEY identity (100,1),
    Product_Description TEXT,
    Product_Quantity INT,
    Product_Price DECIMAL(10, 2),
    OEIMD VARCHAR(50),
    Reorder_Level INT,
    Last_Restock_Date DATE
);


CREATE TABLE Orders (
    OrderID INT PRIMARY KEY identity (100,1),
    Order_Date DATE,
    Description TEXT,
    Status VARCHAR(10) CHECK (Status IN ('Completed', 'Pending' ,'Refunded','Invalid')),
    EmployeeID INT,
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);


CREATE TABLE Order_Line (
    Order_Line INT PRIMARY KEY identity (100,1),
    OrderID INT,
    ProductID INT,
    Order_Quantity INT,
    Total_Line_Cost DECIMAL(10, 2),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);


CREATE TABLE Payment (
    PaymentID INT PRIMARY KEY identity (100,1),
    OrderID INT,
    Transaction_Date DATE,
    Amount_Paid DECIMAL(10, 2),
    Payment_Status VARCHAR(50),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);


CREATE TABLE Sales (
    TransactionID INT PRIMARY KEY identity (100,1),
    OrderID INT,
    Transaction_Date DATE,
    Total_Amount DECIMAL(10, 2),
    Tax_Amount DECIMAL(10, 2),
    EmployeeID INT,
    PaymentID INT,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID),
    FOREIGN KEY (PaymentID) REFERENCES Payment(PaymentID)
);

CREATE TABLE Sales_Line (
    Sales_LineID INT PRIMARY KEY identity (100,1),
    TransactionID INT,
    Quantity_Sold INT,
    Unit_Price DECIMAL(10, 2),
    Total_Line_Price DECIMAL(10, 2),
    ProductID INT,
    FOREIGN KEY (TransactionID) REFERENCES Sales(TransactionID),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);

CREATE TABLE Category (
    CategoryID INT PRIMARY KEY IDENTITY(5,10),
    CategoryName VARCHAR(50) NOT NULL UNIQUE,
    Description TEXT
)

ALTER TABLE Product
ADD CategoryID INT;


ALTER TABLE Product
ADD CONSTRAINT fk_prod_categ
FOREIGN KEY (CategoryID)
REFERENCES Category(CategoryID);

--INSERTION OF PRODUCTS AND CATEJORY (NEED PARA MAKA-ORDER SA STAFF SIDE PO)
insert into Category (CategoryName, Description) 
values
('Ball Joint', 'A circle bearing that connects the steering knuckle'),
('Tie Rod End', 'Connects the tie rod to the steering knuckle'),
('Stabilizer Link', 'Connects the stabilizer bar to suspension components to reduce body roll'),
('Tie Rod Rack End', 'Connects to the steering rack'),
('Oil', 'Various types of auto oil.')

insert into Product (Product_Description, Product_Quantity, Product_Price, OEIMD, Reorder_Level, Last_Restock_Date, CategoryID)
values
('Ball Joint (TYT - Upper TAMARAW GAS)', 9, 250.00, '43310-29015', 5, '2024-11-15', 5),
('Tie Rod End (TYT - Outer RH CORONA ST191)', 40, 300.00, '43330-29035', 5, '2024-11-15', 15),
('Stabilizer Link (TYT - Front COROLLA)', 24, 350.00, '43350-39065', 5, '2024-11-15', 25),
('Ball Joint (MSB - Lower MIRAGEG4)', 18, 400.00, 'MB-176308', 5, '2024-11-15', 5),
('Tie Rod End (MSB - InnerRH L-200PICK UP)', 39, 420.00, 'MB-831037', 10, '2024-11-16', 15),
('Stabilizer Link (MSB - FRT GALANT)', 30, 420.00, 'MB-831038', 5, '2024-11-16', 25),
('Tie Rod Rack End (TYT - Inner)', 50, 300.00, '45047-29045', 5, '2024-11-16', 35),
('Oil (TYT - 10W30)', 48, 300.00, '45046-29165', 5, '2024-11-16', 45),
('Ball Joint (MSB - Upper PAJERO)', 38, 250.00, 'MA-159982', 5, '2024-11-16', 5),
('Tie Rod End (MSB - InnerLH L-200PICKUP)', 44, 300.00, 'MB-076004', 5, '2024-11-16', 15),
('Stabilizer Link (MSB - RR LANCER)', 50, 260.00, 'MB-122011', 5, '2024-11-16', 25),
('Ball Joint (SZK - Lower VITARA)', 20, 220.00, '48810-82000', 5, '2024-11-16', 5),
('Tie Rod End (SZK - Inner VITARA)', 49, 400.00, '48820-77E00', 5, '2024-11-17', 15),
('Stabilizer Link (SZK - Front VITARA)', 30, 720.00, '48810/20-65D00', 5, '2024-11-17', 25),
('Tie Rod Rack End (TYT - Outer)', 46, 250.00, '48830-20010', 5, '2024-11-17', 35),
('Ball Joint (MSB - UpperRR PAJERO)', 50, 280.00, 'MR-374521', 5, '2024-11-18', 5),
('Tie Rod End (TYT - Inner RH HILUX)', 37, 300.00, '45503-29355', 5, '2024-11-18', 15),
('Stabilizer Link (TYT - Rear COROLLA)', 45, 280.00, '45503-12130', 5, '2024-11-18', 25),
('Tie Rod Rack End (MSB - Inner LANCER)', 49, 250.00, 'MB-553249', 5, '2024-11-18', 35),
('Ball Joint (SZK - Upper SWIFT)', 49, 250.00, '48830-84000', 5, '2024-11-19', 5),
('Tie Rod End (SZK - Outer WAGON)', 50, 250.00, '48830-63J00', 5, '2024-11-20', 15),
('Stabilizer Link (MSB - FRT LANCER)', 38, 250.00, 'MB-130807', 5, '2024-11-20', 25),
('Ball Joint (MSB - Upper Front)', 50, 380.00, 'MB-501017', 5, '2024-11-18', 5),
('Ball Joint (MSB - Lower Front)', 50, 420.00, 'MB-553249', 5, '2024-11-18', 5),
('Ball Joint (MSB - Upper Rear)', 50, 400.00, 'MB-130807', 5, '2024-11-18', 5),
('Ball Joint (TYT - Upper Front)', 50, 320.00, 'MR-491358', 5, '2024-11-18', 5),
('Ball Joint (TYT - Lower Front)', 50, 350.00, '4422A012', 5, '2024-11-18', 5),
('Ball Joint (TYT - Upper Rear)', 50, 380.00, '8-94224-550-4', 5, '2024-11-18', 5),
('Ball Joint (SZK - Lower Rear)', 50, 380.00, '8-94226-967-2', 5, '2024-11-18', 5),
('Ball Joint (SZK - Upper SUV)', 50, 400.00, '8-94365-165-0', 5, '2024-11-18', 5),
('Ball Joint (SZK - Lower SUV)', 50, 420.00, '8-98025-499-0', 5, '2024-11-18', 5),
('Oil (TYT - 10W30 Synthetic)', 50, 120.00, 'O8910843-1', 5, '2024-11-18', 45),
('Oil (MSB - 5W30 Full Synthetic)', 50, 160.00, 'O8910843-2', 5, '2024-11-18', 45),
('Oil (SZK - 10W40 Diesel)', 50, 239.00, 'O8910843-3', 5, '2024-11-18', 45),
('Oil (TYT - 0W20 Full Synthetic)', 50, 199.00, 'O8910843-4', 5, '2024-11-18', 45),
('Oil (MSB - 10W30 High Mileage)', 50, 250.00, 'O8910843-5', 5, '2024-11-18', 45),
('Oil (MSB - 10W30 Mileage)', 50, 230.00, 'O8910843-6', 5, '2024-11-18', 45),
('Tie Rod End (MSB - InnerRH PAJERO)', 50, 320.00, 'MB-234567', 5, '2024-11-18', 15),
('Tie Rod End (MSB - OuterRH LANCER)', 50, 270.00, 'MB-345678', 5, '2024-11-18', 15),
('Tie Rod End (SZK - InnerLH GRAND VITARA)', 50, 290.00, 'SZ-456789', 5, '2024-11-18', 15),
('Tie Rod End (SZK - InnerRH JIMNY)', 49, 310.00, 'SZ-678901', 5, '2024-11-18', 15),
('Tie Rod End (TYT - InnerLH HILUX)', 50, 300.00, 'TY-789012', 5, '2024-11-18', 15),
('Tie Rod End (TYT - OuterRH FORTUNER)', 50, 330.00, 'TY-890123', 5, '2024-11-18', 15),
('Tie Rod Rack End (MSB - InnerLH PAJERO)', 50, 320.00, 'MN-101368', 5, '2024-11-18', 35),
('Tie Rod Rack End (MSB - OuterRH L200)', 50, 280.00, '8-97018-227-2', 5, '2024-11-18', 35),
('Tie Rod Rack End (TYT - InnerLH HILUX)', 50, 310.00, 'MN-101368', 5, '2024-11-18', 35),
('Tie Rod Rack End (TYT - OuterRH FORTUNER)', 50, 270.00, '8-97018-227-2', 5, '2024-11-18', 35),
('Tie Rod Rack End (SZK - InnerLH GRAND VITARA)', 50, 340.00, 'MN-101368', 5, '2024-11-18', 35),
('Tie Rod Rack End (SZK - OuterRH JIMNY)', 50, 290.00, '8-97018-227-2', 5, '2024-11-18', 35),
('Stabilizer Link (TYT -FrontHILUX)', 50, 390.00, 'TY-772055', 5, '2024-11-18', 25),
('Stabilizer Link (TYT- RRFORTUNER)', 50, 360.00, 'TY-772056', 5, '2024-11-18', 25),
('Stabilizer Link (MSB - FrontPAJERO)', 50, 380.00, 'MB-882011', 5, '2024-11-18', 25),
('Stabilizer Link (MSB -RR L200)', 50, 350.00, 'MB-882012', 5, '2024-11-18', 25),
('Stabilizer Link (SZK -Front GVITARA)', 50, 400.00, 'SZ-992033', 5, '2024-11-18', 25),
('Stabilizer Link (SZK - RR JIMNY)', 50, 370.00, 'SZ-992034', 5, '2024-11-18', 25)
