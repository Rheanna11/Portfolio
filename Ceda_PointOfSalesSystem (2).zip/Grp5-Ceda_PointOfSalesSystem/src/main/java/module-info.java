module com.admin.inventory.projectadminfinal {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires itextpdf;
    requires com.microsoft.sqlserver.jdbc;
    requires io;
    requires kernel;
    requires layout;


    opens com.admin.inventory.projectadminfinal to javafx.fxml;
    exports com.admin.inventory.projectadminfinal;
}