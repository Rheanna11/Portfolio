package com.admin.inventory.projectadminfinal;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class MainLogin extends Application {

    public static void showDashboard(String role, String username) {
        try {
            if ("admin".equalsIgnoreCase(role)) {
                // Loads Admin Dashboard from FXML
                String fxmlFile = "/com/admin/inventory/projectadminfinal/AdminDashboard.fxml";
                URL fxmlLocation = Main.class.getResource(fxmlFile);
                if (fxmlLocation == null) {
                    throw new IllegalArgumentException("FXML file not found: " + fxmlFile);
                }

                Parent root = FXMLLoader.load(fxmlLocation);
                Stage stage = new Stage();
                stage.setTitle("Ceda Autoshop - Admin");
                stage.setScene(new Scene(root, 1200, 900));
                stage.setResizable(true);
                stage.show();
            } else if ("staff".equalsIgnoreCase(role)) {
                // Create and show the Dashboard for staff
                Dashboard dashboard = new Dashboard();
                dashboard.showDashboard(role, username);
            } else {
                throw new IllegalArgumentException("Unknown role: " + role);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void start(Stage primaryStage) {
        LoginWindow login = new LoginWindow();
        login.setOnLoginSuccess(MainLogin::showDashboard);
        try {
            login.start(primaryStage); // Use the primary stage given by JavaFX
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}