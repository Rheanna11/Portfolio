package com.admin.inventory.projectadminfinal;


import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.*;
import java.sql.*;
import java.util.Optional;
import javafx.scene.Scene;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

// DASHBOARD for uses
public class Dashboard {

    private static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=CEDA;integratedSecurity=true;encrypt=true;trustServerCertificate=true";

    private String currentUser;
    private String userRole;
    private final ObservableList<OrderItem> cartItems = FXCollections.observableArrayList();
    private double totalAmount = 0.0;
    private VBox rightPane;
    private GridPane productGrid;

    private ComboBox<String> categoryComboBox;
    private TextField chosenProductTextField;
    private Spinner<Integer> quantitySpinner;
    private TextField totalLineTextField;

    public void showDashboard(String role, String username) {
        this.userRole = role;
        this.currentUser = username;

        Stage stage = new Stage();
        stage.setTitle("Dashboard - " + role + " (" + username + ")");
        stage.setResizable(false);
        stage.setFullScreen(true);

        BorderPane pane = new BorderPane();

        // Top Bar
        HBox topBar = createTopBar(username);
        pane.setTop(topBar);

        // Main Content
        GridPane mainContent = createMainContent();
        pane.setCenter(mainContent);

        Scene scene = new Scene(pane, 1200, 613);
        stage.setScene(scene);
        stage.show();
    }

    private HBox createTopBar(String username) {
        HBox topBar = new HBox();
        topBar.setPrefHeight(30);
        topBar.setStyle("-fx-background-color: rgb(40, 84, 141); -fx-padding: 10px 20px;");
        topBar.setAlignment(Pos.CENTER_RIGHT);

        Label userLabel = new Label("Welcome, " + username + " (" + userRole + ")");
        userLabel.setFont(new Font(24));
        userLabel.setStyle("-fx-text-fill:rgb(255, 255, 255);-fx-padding: 5px; -fx-border-width: 1px; -fx-border-radius: 5px; -fx-alignment: center-right;");

        Button logoutButton = new Button("Log Out");
        logoutButton.setStyle("-fx-font-size: 14px; -fx-padding: 5px; -fx-background-color: #f44336; -fx-text-fill: white;");
        logoutButton.setOnAction(e -> {
            Stage currentStage = (Stage) topBar.getScene().getWindow();
            currentStage.close();
            new MainLogin().start(new Stage());
        });

        HBox.setMargin(logoutButton, new Insets(0, 0, 0, 10));
        topBar.getChildren().addAll(userLabel, logoutButton);

        return topBar;
    }

    private GridPane createMainContent() {
        GridPane mainContent = new GridPane();
        mainContent.setHgap(10);
        mainContent.setVgap(10);
        mainContent.setPadding(new Insets(10));
        mainContent.setStyle("-fx-background-color: rgba(214, 214, 214, 0.57);");

        // Product Category Section
        GridPane productCategory = createProductCategorySection();
        mainContent.add(productCategory, 0, 0);

        // Product Grid Section
        productGrid = createProductGridSection();
        mainContent.add(productGrid, 0, 1);

        // Right Pane Section
        rightPane = createRightPane();
        mainContent.add(rightPane, 1, 0, 1, 2);

        // Make columns and rows responsive
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPercentWidth(70);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPercentWidth(30);
        mainContent.getColumnConstraints().addAll(col1, col2);

        RowConstraints row1 = new RowConstraints();
        row1.setVgrow(Priority.ALWAYS);
        RowConstraints row2 = new RowConstraints();
        row2.setVgrow(Priority.ALWAYS);
        mainContent.getRowConstraints().addAll(row1, row2);

        return mainContent;
    }

    //product list
    private GridPane createProductCategorySection() {
        GridPane productCategory = new GridPane();
        productCategory.setHgap(10);
        productCategory.setVgap(10);
        productCategory.setPadding(new Insets(10));
        productCategory.setStyle("-fx-background-color: #f0f0f0; -fx-border-color: #ccc; -fx-border-width: 1px;");
        productCategory.setMaxSize(1400, 200);

        Label productCategoryLabel = new Label("Product Category");
        productCategoryLabel.setFont(new Font(16));
        productCategoryLabel.setStyle("-fx-text-fill: #333; -fx-padding: 5px;");
        productCategory.add(productCategoryLabel, 0, 0);

        Label productIDLabel = new Label("Product ID");
        productIDLabel.setFont(new Font(16));
        productIDLabel.setStyle("-fx-text-fill: #333; -fx-padding: 5px;");
        productCategory.add(productIDLabel, 1, 0);

        Label productqtyLabel = new Label("Quantity");
        productqtyLabel.setFont(new Font(16));
        productqtyLabel.setStyle("-fx-text-fill: #333; -fx-padding: 5px;");
        productCategory.add(productqtyLabel, 2, 0);

        Label productTotalLabel = new Label("Total Line Price");
        productTotalLabel.setFont(new Font(16));
        productTotalLabel.setStyle("-fx-text-fill: #333; -fx-padding: 5px;");
        productCategory.add(productTotalLabel, 3, 0);

        //category comobox
        categoryComboBox = new ComboBox<>();
        try (Connection connection = DriverManager.getConnection(DB_URL)) {
            String query = "SELECT CategoryName FROM Category";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            ObservableList<String> categories = FXCollections.observableArrayList();
            while (resultSet.next()) {
                categories.add(resultSet.getString("CategoryName"));
            }
            categoryComboBox.setItems(categories);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to load product categories: " + e.getMessage());
        }

        categoryComboBox.setPromptText("Select Category");
        categoryComboBox.setStyle("-fx-font-size: 14px; -fx-padding: 5px; -fx-background-color: #fff; -fx-border-color: #ccc; -fx-border-width: 1px;");
        productCategory.add(categoryComboBox, 0, 1);
        GridPane.setHgrow(categoryComboBox, Priority.ALWAYS);

        chosenProductTextField = new TextField();
        chosenProductTextField.setPromptText("Product ID");
        chosenProductTextField.setEditable(false);
        chosenProductTextField.setStyle("-fx-font-size: 14px; -fx-padding: 5px; -fx-background-color: #fff; -fx-border-color: #ccc; -fx-border-width: 1px;");
        productCategory.add(chosenProductTextField, 1, 1);
        GridPane.setHgrow(chosenProductTextField, Priority.ALWAYS);

        quantitySpinner = new Spinner<>(1, 100, 1);
        quantitySpinner.setStyle("-fx-font-size: 14px; -fx-padding: 5px; -fx-background-color: #fff; -fx-border-color: #ccc; -fx-border-width: 1px;");
        productCategory.add(quantitySpinner, 2, 1);
        GridPane.setHgrow(quantitySpinner, Priority.ALWAYS);

        totalLineTextField = new TextField();
        totalLineTextField.setPromptText("00.00");
        totalLineTextField.setEditable(false);
        totalLineTextField.setStyle("-fx-font-size: 14px; -fx-padding: 5px; -fx-background-color: #fff; -fx-border-color: #ccc; -fx-border-width: 1px;");
        productCategory.add(totalLineTextField, 3, 1);
        GridPane.setHgrow(totalLineTextField, Priority.ALWAYS);

        Button addToCartButton = createButton("Add to Cart", "#4CAF50", e -> addToCart());
        productCategory.add(addToCartButton, 2, 2);
        GridPane.setHgrow(addToCartButton, Priority.ALWAYS);

        Button clearButton = createButton("Clear", "#f44336", e -> {
            categoryComboBox.getSelectionModel().clearSelection();
            chosenProductTextField.clear();
            quantitySpinner.getValueFactory().setValue(1);
            totalLineTextField.clear();
            updateProductGrid(null);
        });
        productCategory.add(clearButton, 3, 2);
        GridPane.setHgrow(clearButton, Priority.ALWAYS);

        //event handlinf for category selection
        categoryComboBox.setOnAction(e -> {
            String selectedCategoryName = categoryComboBox.getValue();
            updateProductGrid(selectedCategoryName);

            if (selectedCategoryName != null) {
                try (Connection connection = DriverManager.getConnection(DB_URL)) {
                    String query = "SELECT p.ProductID, p.Product_Price, p.Product_Description " +  //selection frpm product table
                            "FROM Product p " +
                            "JOIN Category c ON p.CategoryID = c.CategoryID " +
                            "WHERE c.CategoryName = ?";
                    PreparedStatement statement = connection.prepareStatement(query);
                    statement.setString(1, selectedCategoryName);
                    ResultSet resultSet = statement.executeQuery();

                    if (resultSet.next()) {
                        chosenProductTextField.setText(String.valueOf(resultSet.getInt("ProductID")));
                        totalLineTextField.setText("P" + resultSet.getDouble("Product_Price"));
                    } else {
                        chosenProductTextField.clear();
                        totalLineTextField.clear();
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    showAlert("Database Error", "Failed to load product details: " + ex.getMessage());
                }
            } else {
                chosenProductTextField.clear();
                totalLineTextField.clear();
            }
        });

        return productCategory;
    }

    private void addToCart() {
        if (chosenProductTextField.getText().isEmpty()) {
            showAlert("Error", "Please select a product first");
            return;
        }

        int productId = Integer.parseInt(chosenProductTextField.getText());
        int quantity = quantitySpinner.getValue();
        double price = Double.parseDouble(totalLineTextField.getText().replace("P", ""));
        double totalPrice = price * quantity;

        String productDescription = getProductDescription(productId);

        //check if product already exists in cart, tjen add to it
        boolean found = false;
        for (OrderItem item : cartItems) {
            if (item.getProductId() == productId) {
                // Update existing item
                item.setQuantity(item.getQuantity() + quantity);
                item.setTotalPrice(item.getTotalPrice() + totalPrice);
                found = true;
                break;
            }
        }

        // not found, new row
        if (!found) {
            //add new item
            OrderItem item = new OrderItem(
                    productId,
                    productDescription,
                    quantity,
                    price,
                    totalPrice
            );
            cartItems.add(item);
        }

        totalAmount += totalPrice;
        updateOrderList();

        //clear selection after addin sa cart. new
        categoryComboBox.getSelectionModel().clearSelection();
        chosenProductTextField.clear();
        quantitySpinner.getValueFactory().setValue(1);
        totalLineTextField.clear();
        updateProductGrid(null);
    }

    private String getProductDescription(int productId) {
        try (Connection connection = DriverManager.getConnection(DB_URL)) {
            String query = "SELECT Product_Description FROM Product WHERE ProductID = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, productId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getString("Product_Description");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to get product description: " + e.getMessage());
        }
        return "Unknown Product";
    }

    private GridPane createProductGridSection() {
        productGrid = new GridPane();
        productGrid.setHgap(10);
        productGrid.setVgap(10);
        productGrid.setPadding(new Insets(10));
        productGrid.setStyle("-fx-background-color: #f0f0f0; -fx-border-color: #ccc; -fx-border-width: 1px;");
        productGrid.setPrefHeight(800);

        // Initially load all products
        updateProductGrid(null);

        return productGrid;
    }

    private void updateProductGrid(String categoryName) {
        productGrid.getChildren().clear();

        try (Connection connection = DriverManager.getConnection(DB_URL)) {
            String query;
            PreparedStatement statement;

            if (categoryName != null && !categoryName.isEmpty()) {
                query = "SELECT p.ProductID, p.Product_Description, p.Product_Price, c.CategoryName " +
                        "FROM Product p JOIN Category c ON p.CategoryID = c.CategoryID " +
                        "WHERE c.CategoryName = ?";
                statement = connection.prepareStatement(query);
                statement.setString(1, categoryName);
            } else {
                query = "SELECT p.ProductID, p.Product_Description, p.Product_Price, c.CategoryName " +
                        "FROM Product p JOIN Category c ON p.CategoryID = c.CategoryID";
                statement = connection.prepareStatement(query);
            }

            ResultSet resultSet = statement.executeQuery();

            int columns = 6;
            int row = 0;
            int col = 0;

            while (resultSet.next()) {
                int productId = resultSet.getInt("ProductID");
                String description = resultSet.getString("Product_Description");
                double price = resultSet.getDouble("Product_Price");
                String productCategory = resultSet.getString("CategoryName");

                Button productButton = new Button(description + "\nP" + price);
                productButton.setPrefSize(150, 100);
                productButton.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
                productButton.setStyle("-fx-font-size: 12px; -fx-text-alignment: center;");
                productButton.setOnAction(e -> {
                    categoryComboBox.getSelectionModel().select(productCategory);
                    chosenProductTextField.setText(String.valueOf(productId));
                    totalLineTextField.setText("P" + price);
                    quantitySpinner.getValueFactory().setValue(1);
                    addToCart();
                });

                productGrid.add(productButton, col, row);
                GridPane.setHgrow(productButton, Priority.ALWAYS);
                GridPane.setVgrow(productButton, Priority.ALWAYS);

                col++;
                if (col >= columns) {
                    col = 0;
                    row++;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to load products: " + e.getMessage());
        }
    }

    private VBox createRightPane() {
        rightPane = new VBox();
        rightPane.setSpacing(10);
        rightPane.setPadding(new Insets(10));
        rightPane.setStyle("-fx-background-color: #ffffff; -fx-border-color: #ccc; -fx-border-width: 1px;");

        Label orderListLabel = new Label("Order List:");
        orderListLabel.setFont(new Font(16));

        VBox orderList = new VBox();
        orderList.setSpacing(5);
        orderList.setStyle("-fx-background-color: #f9f9f9; -fx-border-color: #ccc; -fx-border-width: 1px; -fx-padding: 10px;");

        // tableView order list
        TableView<OrderItem> orderTable = new TableView<>();
        orderTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<OrderItem, String> productCol = new TableColumn<>("Product");
        productCol.setCellValueFactory(new PropertyValueFactory<>("productDescription"));

        TableColumn<OrderItem, Integer> qtyCol = new TableColumn<>("Qty");
        qtyCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));

        TableColumn<OrderItem, Double> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("unitPrice"));

        TableColumn<OrderItem, Double> totalCol = new TableColumn<>("Total");
        totalCol.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));

        //delete button column
        TableColumn<OrderItem, Void> actionCol = new TableColumn<>("Action");
        actionCol.setCellFactory(param -> new TableCell<>() {
            private final Button deleteButton = new Button("Delete");

            {
                deleteButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");
                deleteButton.setOnAction(event -> {
                    OrderItem item = getTableView().getItems().get(getIndex());
                    confirmAndDeleteItem(item);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(deleteButton);
                }
            }
        });

        orderTable.getColumns().addAll(productCol, qtyCol, priceCol, totalCol, actionCol);
        orderTable.setItems(cartItems);
        orderList.getChildren().add(orderTable);

        Label totalAmountLabel = new Label("TOTAL AMOUNT: P0.00");
        totalAmountLabel.setFont(new Font(16));
        totalAmountLabel.setStyle("-fx-text-fill: green;");
        totalAmountLabel.setId("totalAmountLabel");

        Button payButton = createButton("PAY AND RECEIPT", "green", e -> processPayment());

        rightPane.getChildren().addAll(orderListLabel, orderList, totalAmountLabel, payButton);
        VBox.setVgrow(orderList, Priority.ALWAYS);

        return rightPane;
    }

    private void confirmAndDeleteItem(OrderItem item) {
        Stage mainStage = (Stage) rightPane.getScene().getWindow();

        //ask confirmation of deletion by staff
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirm Deletion");
        confirmation.setHeaderText("Delete Item");
        confirmation.setContentText("Are you sure you want to delete " + item.getProductDescription() + " from the cart?");

        //override yessss unf main
        confirmation.initOwner(mainStage);

        Optional<ButtonType> result = confirmation.showAndWait();
        if (result.isEmpty() || result.get() != ButtonType.OK) return;

        //ask password
        TextInputDialog passwordDialog = new TextInputDialog();
        passwordDialog.setTitle("Authentication Required");
        passwordDialog.setHeaderText("Enter your password to confirm deletion");
        passwordDialog.setContentText("Password:");

        passwordDialog.initOwner(mainStage);

        Optional<String> passwordResult = passwordDialog.showAndWait();
        if (passwordResult.isEmpty()) return;

        String enteredPassword = passwordResult.get();

        //validation staff sa dbase
        try (Connection connection = DriverManager.getConnection(DB_URL)) {
            String query = "SELECT Password FROM Employee WHERE CONCAT(First_Name, ' ', Middle_Name, ' ', Last_Name) = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, currentUser);
                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    String storedPassword = resultSet.getString("Password");

                    if (enteredPassword.equals(storedPassword)) {
                        // Step 4: Remove item from cart
                        cartItems.remove(item);
                        totalAmount -= item.getTotalPrice();
                        updateOrderList();
                    } else {
                        showAlert("Error", "Incorrect password. Deletion canceled.");
                    }
                } else {
                    showAlert("Error", "User not found. Deletion canceled.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to verify password: " + e.getMessage());
        }
    }

    private void updateOrderList() {
        Label totalLabel = (Label) rightPane.lookup("#totalAmountLabel");
        if (totalLabel != null) {
            totalLabel.setText(String.format("TOTAL AMOUNT: P%.2f", totalAmount));
        }
    }

    private void processPayment() {
        if (cartItems.isEmpty()) {
            showAlert("Error", "No items in cart to process payment");
            return;
        }

        Stage mainStage = (Stage) rightPane.getScene().getWindow();

        TextInputDialog cashDialog = new TextInputDialog();
        cashDialog.setTitle("Payment Processing");
        cashDialog.setHeaderText("Enter Cash Amount");
        cashDialog.setContentText("Amount:");
        cashDialog.initOwner(mainStage);

        Optional<String> cashResult = cashDialog.showAndWait();
        if (!cashResult.isPresent() || cashResult.get().isEmpty()) {
            return;
        }

        try {
            double cashAmount = Double.parseDouble(cashResult.get());
            if (cashAmount < totalAmount) {
                showAlert("Error", "Cash amount is less than total amount");
                return;
            }

            double change = cashAmount - totalAmount;

            try (Connection connection = DriverManager.getConnection(DB_URL)) {
                connection.setAutoCommit(false);

                int employeeId = getEmployeeId(currentUser);
                if (employeeId == -1) {
                    showAlert("Error", "Employee not found");
                    return;
                }

                // insetrt to ORDER table
                String orderQuery = "INSERT INTO Orders (Order_Date, Description, Status, EmployeeID) VALUES (?, ?, ?, ?)";
                PreparedStatement orderStmt = connection.prepareStatement(orderQuery, Statement.RETURN_GENERATED_KEYS);
                orderStmt.setDate(1, new java.sql.Date(System.currentTimeMillis()));
                orderStmt.setString(2, "Order from " + currentUser);
                orderStmt.setString(3, "Completed");
                orderStmt.setInt(4, employeeId);
                orderStmt.executeUpdate();

                ResultSet generatedKeys = orderStmt.getGeneratedKeys();
                int orderId = -1;
                if (generatedKeys.next()) {
                    orderId = generatedKeys.getInt(1);
                }

                // insert to ORDER_LINE table
                String orderLineQuery = "INSERT INTO Order_Line (OrderID, ProductID, Order_Quantity, Total_Line_Cost) VALUES (?, ?, ?, ?)";
                PreparedStatement orderLineStmt = connection.prepareStatement(orderLineQuery);

                for (OrderItem item : cartItems) {
                    orderLineStmt.setInt(1, orderId);
                    orderLineStmt.setInt(2, item.getProductId());
                    orderLineStmt.setInt(3, item.getQuantity());
                    orderLineStmt.setDouble(4, item.getTotalPrice());
                    orderLineStmt.addBatch();

                    updateProductQuantity(connection, item.getProductId(), item.getQuantity());
                }
                orderLineStmt.executeBatch();

                //insert to PAYMENT table
                String paymentQuery = "INSERT INTO Payment (OrderID, Transaction_Date, Amount_Paid, Payment_Status) VALUES (?, ?, ?, ?)";
                PreparedStatement paymentStmt = connection.prepareStatement(paymentQuery, Statement.RETURN_GENERATED_KEYS);
                paymentStmt.setInt(1, orderId);
                paymentStmt.setDate(2, new java.sql.Date(System.currentTimeMillis()));
                paymentStmt.setDouble(3, totalAmount);
                paymentStmt.setString(4, "Paid");
                paymentStmt.executeUpdate();

                // get generated PaymentID
                ResultSet paymentKeys = paymentStmt.getGeneratedKeys();
                int paymentId = -1;
                if (paymentKeys.next()) {
                    paymentId = paymentKeys.getInt(1);
                }

                // tax calculaltion
                double taxAmount = totalAmount * 0.12;
                double totalWithTax = totalAmount + taxAmount;

                // insert to SALES table
                String salesQuery = "insert into Sales (OrderID, Transaction_Date, Total_Amount, Tax_Amount, EmployeeID, PaymentID) values (?, ?, ?, ?, ?, ?)";
                PreparedStatement salesStmt = connection.prepareStatement(salesQuery, Statement.RETURN_GENERATED_KEYS);
                salesStmt.setInt(1, orderId);
                salesStmt.setDate(2, new java.sql.Date(System.currentTimeMillis()));
                salesStmt.setDouble(3, totalWithTax);
                salesStmt.setDouble(4, taxAmount);
                salesStmt.setInt(5, employeeId);
                salesStmt.setInt(6, paymentId);
                salesStmt.executeUpdate();

                // get the generated TransactionID from salestable
                ResultSet salesKeys = salesStmt.getGeneratedKeys();
                int transactionId = -1;
                if (salesKeys.next()) {
                    transactionId = salesKeys.getInt(1);
                }

                //insert into Sales_LINE table
                String salesLineQuery = "insert into Sales_Line (TransactionID, Quantity_Sold, Unit_Price, Total_Line_Price, ProductID) values (?, ?, ?, ?, ?)";
                PreparedStatement salesLineStmt = connection.prepareStatement(salesLineQuery);

                for (OrderItem item : cartItems) {
                    double unitPrice = item.getTotalPrice() / item.getQuantity();

                    salesLineStmt.setInt(1, transactionId);
                    salesLineStmt.setInt(2, item.getQuantity());
                    salesLineStmt.setDouble(3, unitPrice);
                    salesLineStmt.setDouble(4, item.getTotalPrice());
                    salesLineStmt.setInt(5, item.getProductId());
                    salesLineStmt.addBatch();
                }
                salesLineStmt.executeBatch();

                connection.commit();

                ReceiptGenerator.showReceipt(
                        mainStage,
                        currentUser,
                        cartItems,
                        totalAmount,
                        orderId,
                        cashAmount,
                        change
                );

                cartItems.clear();
                totalAmount = 0.0;
                updateOrderList();

            } catch (SQLException e) {
                e.printStackTrace();
                showAlert("Error", "Failed to process payment: " + e.getMessage());
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "Please enter a valid number for cash amount");
        }
    }
    private int getEmployeeId(String username) throws SQLException {
        try (Connection connection = DriverManager.getConnection(DB_URL)) {
            String query = "SELECT EmployeeID FROM Employee WHERE CONCAT(First_Name, ' ', Middle_Name, ' ', Last_Name) = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("EmployeeID");
            }
        }
        return -1;
    }

    private void updateProductQuantity(Connection connection, int productId, int quantitySold) throws SQLException {
        String query = "UPDATE Product SET Product_Quantity = Product_Quantity - ? WHERE ProductID = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, quantitySold);
        statement.setInt(2, productId);
        statement.executeUpdate();
    }

    private Button createButton(String text, String color, javafx.event.EventHandler<javafx.event.ActionEvent> action) {
        Button button = new Button(text);
        button.setStyle("-fx-font-size: 14px; -fx-padding: 5px; -fx-background-color: " + color + "; -fx-text-fill: white;");
        button.setOnAction(action);
        return button;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}