package com.admin.inventory.projectadminfinal;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;


import java.sql.*;
import java.util.Objects;
import java.util.function.BiConsumer;

public class LoginWindow extends Application {

    private static final String DB_URL =
            "jdbc:sqlserver://localhost:1433;databaseName=CEDA;integratedSecurity=true;encrypt=true;trustServerCertificate=true";

    private BiConsumer<String, String> onLoginSuccess;

    public void setOnLoginSuccess(BiConsumer<String, String> onLoginSuccess) {
        this.onLoginSuccess = onLoginSuccess;
    }

    @Override
    public void start(Stage stage) {

        Pane pane = new Pane();
        pane.setPrefSize(500, 300);
        pane.setStyle("-fx-background-color: #eeeeee;");
        Image icon = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/com/admin/inventory/projectadminfinal/images/cedAlogocopy.png")));
        stage.getIcons().add(icon);

        // Add logo
        Image image = new Image(Objects.requireNonNull(getClass().getResource("/com/admin/inventory/projectadminfinal/images/cedAlogo.png")).toExternalForm());
        ImageView imageView = new ImageView(image);
        imageView.setLayoutX(150);     // Adjust horizontally
        imageView.setLayoutY(10);      // Top aligned
        imageView.setFitHeight(80);    // Reduce size
        imageView.setPreserveRatio(true);
        pane.getChildren().add(imageView);

        System.out.println(">>> LoginWindow started");
        stage.setTitle("Ceda Login");
        stage.setResizable(false);


// Position Y after the logo
        double baseY = 130;

// Employee ID label and text field
        Label empIDLabel = createLabel("Employee ID:", 50, baseY);
        TextField empIDTF = new TextField();
        empIDTF.setLayoutX(170);
        empIDTF.setLayoutY(baseY);
        empIDTF.setPrefWidth(200);
        empIDTF.setPromptText("Enter Employee ID");

// Password label and field
        Label passLabel = createLabel("Password:", 50, baseY + 50);
        PasswordField passTF = new PasswordField();
        passTF.setLayoutX(170);
        passTF.setLayoutY(baseY + 50);
        passTF.setPrefWidth(200);
        passTF.setPromptText("Enter Password");

// Login button
        Button loginBtn = new Button("LOGIN");
        loginBtn.setLayoutX(170);
        loginBtn.setLayoutY(baseY + 100);
        loginBtn.setPrefWidth(200);
        loginBtn.setStyle("-fx-font-size: 14px;");

        loginBtn.setOnMouseEntered(e -> loginBtn.setStyle("-fx-background-color: #6B9BDA;"));
        loginBtn.setOnMouseExited(e -> loginBtn.setStyle(""));

        loginBtn.setOnAction(e -> handleLogin(empIDTF, passTF, stage));
        passTF.setOnAction(e -> handleLogin(empIDTF, passTF, stage));

        pane.getChildren().addAll(empIDLabel, passLabel, empIDTF, passTF, loginBtn);

        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
    }

    private Label createLabel(String text, double x, double y) {
        Label label = new Label(text);
        label.setLayoutX(x);
        label.setLayoutY(y);
        label.setFont(new Font(16));
        return label;
    }

    private void handleLogin(TextField empIDTF, PasswordField passTF, Stage stage) {
        String empId = empIDTF.getText().trim();
        String password = passTF.getText();

        if (empId.isEmpty() || password.isEmpty()) {
            showAlert("Login Failed", "Please fill in all fields.");
            return;
        }

        if (!empId.matches("\\d+")) {
            showAlert("Invalid Input", "Employee ID must be numeric.");
            return;
        }

        try (Connection connection = DriverManager.getConnection(DB_URL)) {
            String query = "SELECT ROLE, CONCAT(First_Name, ' ', Middle_Name, ' ', Last_Name) AS FullName FROM Employee WHERE EmployeeID = ? AND Password = ? AND Status = 'Active'";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, Integer.parseInt(empId));
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String role = rs.getString("ROLE");
                String username = rs.getString("FullName");

                stage.close(); // Close the login window

                if (onLoginSuccess != null) {
                    onLoginSuccess.accept(role.toLowerCase(), username); // Pass role and username to Main
                }
            } else {
                showAlert("Login Failed", "Invalid Employee ID or Password.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Login failed: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}