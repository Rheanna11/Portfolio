package com.admin.inventory.projectadminfinal;

import java.util.regex.Pattern;

/**
 * Utility class for input validation
 */
public class ValidationUtils {

    // Email validation pattern
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");

    // Phone number validation pattern (simple format)
    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^\\d{10}$");

    /**
     * Validates if a string is a valid email address
     * @param email The email to validate
     * @return True if valid, false otherwise
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email).matches();
    }

    /**
     * Validates if a string is a valid phone number (simple 10-digit check)
     * @param phone The phone number to validate
     * @return True if valid, false otherwise
     */
    public static boolean isValidPhone(String phone) {
        if (phone == null || phone.isEmpty()) {
            return false;
        }
        // Remove any non-digit characters for flexibility
        String digitsOnly = phone.replaceAll("\\D", "");
        return PHONE_PATTERN.matcher(digitsOnly).matches();
    }

    /**
     * Validates if a string can be parsed as an integer
     * @param value The string to check
     * @return True if valid integer, false otherwise
     */
    public static boolean isInteger(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Validates if a string can be parsed as a double
     * @param value The string to check
     * @return True if valid double, false otherwise
     */
    public static boolean isDouble(String value) {
        try {
            Double.parseDouble(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Checks if a string is null or empty
     * @param value The string to check
     * @return True if null or empty, false otherwise
     */
    public static boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }
}