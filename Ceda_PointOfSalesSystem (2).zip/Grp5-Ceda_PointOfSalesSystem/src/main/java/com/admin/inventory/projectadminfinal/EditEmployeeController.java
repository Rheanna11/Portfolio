package com.admin.inventory.projectadminfinal;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class EditEmployeeController implements Initializable {

    @FXML private TextField idField;
    @FXML private TextField firstNameField;
    @FXML private TextField middleNameField;
    @FXML private TextField lastNameField;
    @FXML private ToggleGroup sexGroup;
    @FXML private RadioButton maleRadio;
    @FXML private RadioButton femaleRadio;
    @FXML private DatePicker hireDatePicker;
    @FXML private ComboBox<String> employeeTypeComboBox;
    @FXML private ComboBox<String> roleComboBox;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Label statusLabel;

    private Employee employee;
    private boolean passwordChanged = false;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadEmployeeTypes();
        roleComboBox.setItems(FXCollections.observableArrayList("Admin", "Staff"));

        // Tracks password change if available
        passwordField.textProperty().addListener((observable, oldValue, newValue) -> {
            passwordChanged = !newValue.isEmpty();
        });

        // Disable ID field from being edited
        idField.setEditable(false);
    }

    public void initData(Employee employee) {
        this.employee = employee;

        idField.setText(String.valueOf(employee.getId()));
        firstNameField.setText(employee.getFirstName());
        middleNameField.setText(employee.getMiddleName());
        lastNameField.setText(employee.getLastName());

        if ("M".equals(employee.getSex())) {
            maleRadio.setSelected(true);
        } else {
            femaleRadio.setSelected(true);
        }

        hireDatePicker.setValue(employee.getHireDate());
        employeeTypeComboBox.setValue(employee.getEmployeeType());
        roleComboBox.setValue(employee.getRole());

        passwordField.clear();
        confirmPasswordField.clear();
    }
    // loads existing employee types
    private void loadEmployeeTypes() {
        String sql = "SELECT Employee_Type FROM Employee_Type ORDER BY Employee_Type";
        ObservableList<String> employeeTypes = FXCollections.observableArrayList();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                employeeTypes.add(rs.getString("Employee_Type"));
            }

            employeeTypeComboBox.setItems(employeeTypes);

        } catch (SQLException e) {
            showErrorMessage("Error loading employee types: " + e.getMessage());
        }
    }
    // handles the action of saving the form
    @FXML
    private void handleSave(ActionEvent event) {
        if (!validateInputs()) return;

        try {
            employee.setFirstName(firstNameField.getText().trim());
            employee.setMiddleName(middleNameField.getText().trim());
            employee.setLastName(lastNameField.getText().trim());
            employee.setSex(maleRadio.isSelected() ? "M" : "F");
            employee.setHireDate(hireDatePicker.getValue());
            employee.setEmployeeType(employeeTypeComboBox.getValue());
            employee.setRole(roleComboBox.getValue());

            if (updateEmployee()) {
                closeForm(event);
            }

        } catch (Exception e) {
            showErrorMessage("Error: " + e.getMessage());
        }
    }
    // Validate inputs if there are any empty fields
    private boolean validateInputs() {
        if (ValidationUtils.isEmpty(firstNameField.getText())) {
            showErrorMessage("First Name is required");
            firstNameField.requestFocus();
            return false;
        }

        if (ValidationUtils.isEmpty(lastNameField.getText())) {
            showErrorMessage("Last Name is required");
            lastNameField.requestFocus();
            return false;
        }

        if (hireDatePicker.getValue() == null) {
            showErrorMessage("Hire Date is required");
            hireDatePicker.requestFocus();
            return false;
        }

        if (employeeTypeComboBox.getValue() == null) {
            showErrorMessage("Employee Type is required");
            employeeTypeComboBox.requestFocus();
            return false;
        }

        if (roleComboBox.getValue() == null) {
            showErrorMessage("Role is required");
            roleComboBox.requestFocus();
            return false;
        }

        if (passwordChanged) {
            if (ValidationUtils.isEmpty(passwordField.getText())) {
                showErrorMessage("Password is required");
                passwordField.requestFocus();
                return false;
            }

            if (ValidationUtils.isEmpty(confirmPasswordField.getText())) {
                showErrorMessage("Please confirm your password");
                confirmPasswordField.requestFocus();
                return false;
            }

            if (!passwordField.getText().equals(confirmPasswordField.getText())) {
                showErrorMessage("Passwords do not match");
                confirmPasswordField.requestFocus();
                return false;
            }
        }

        return true;
    }

    private boolean updateEmployee() {
        StringBuilder sqlBuilder = new StringBuilder("UPDATE Employee SET ");
        sqlBuilder.append("First_Name = ?, Middle_Name = ?, Last_Name = ?, Sex = ?, ");
        sqlBuilder.append("Hire_Date = ?, Employee_Type = ?, Role = ?");

        if (passwordChanged) {
            sqlBuilder.append(", Password = ?");
        }

        sqlBuilder.append(" WHERE EmployeeID = ?");

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sqlBuilder.toString())) {

            stmt.setString(1, employee.getFirstName());
            stmt.setString(2, employee.getMiddleName());
            stmt.setString(3, employee.getLastName());
            stmt.setString(4, employee.getSex());
            stmt.setDate(5, java.sql.Date.valueOf(employee.getHireDate()));
            stmt.setString(6, employee.getEmployeeType());
            stmt.setString(7, employee.getRole());

            if (passwordChanged) {
                stmt.setString(8, passwordField.getText());
                stmt.setInt(9, employee.getId());
            } else {
                stmt.setInt(8, employee.getId());
            }

            System.out.println("Executing update for ID: " + employee.getId()); // Debug

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessMessage("Employee updated successfully!");
                return true;
            } else {
                showErrorMessage("No rows updated. Check if ID exists.");
                return false;
            }

        } catch (SQLException e) {
            showErrorMessage("Database error: " + e.getMessage());
            return false;
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeForm(event);
    }

    private void closeForm(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    private void showErrorMessage(String message) {
        statusLabel.setTextFill(Color.RED);
        statusLabel.setText("Error: " + message);
    }

    private void showSuccessMessage(String message) {
        statusLabel.setTextFill(Color.GREEN);
        statusLabel.setText(message);
    }
}
