package com.admin.inventory.projectadminfinal;

public class Transactions {
    private int Sales_LineID;
    private int TransactionID;
    private int ProductID;
    private int QuantitySold;
    private int UnitPrice;
    private int Total_Price_Line;
    private int EmployeeID;

    public Transactions() {
        // Default constructor
    }

    public Transactions(int Sales_LineID, int TransactionID, int ProductID, int QuantitySold,
                        int UnitPrice, int Total_Price_Line, int EmployeeID) {
        this.Sales_LineID = Sales_LineID;
        this.TransactionID = TransactionID;
        this.ProductID = ProductID;
        this.QuantitySold = QuantitySold;
        this.UnitPrice = UnitPrice;
        this.Total_Price_Line = Total_Price_Line;
        this.EmployeeID = EmployeeID;
    }

    public int getId() {
        return Sales_LineID;
    }

    public void setId(int id) {
        this.Sales_LineID = id;
    }

    public int getTransactionID() {
        return TransactionID;
    }

    public void setTransactionID(int TransactionID) {
        this.TransactionID = TransactionID;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public int getQuantitySold() {
        return QuantitySold;
    }

    public void setQuantitySold(int QuantitySold) {
        this.QuantitySold = QuantitySold;
    }

    public int getUnitPrice() {
        return UnitPrice;
    }

    public void setUnitPrice(int UnitPrice) {
        this.UnitPrice = UnitPrice;
    }

    public int getTotal_Price_Line() {
        return Total_Price_Line;
    }

    public void setTotal_Price_Line(int Total_Price_Line) {
        this.Total_Price_Line = Total_Price_Line;
    }

    public int getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(int EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

}