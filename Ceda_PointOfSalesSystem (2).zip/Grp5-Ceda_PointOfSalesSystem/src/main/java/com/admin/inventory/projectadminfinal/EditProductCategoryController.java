package com.admin.inventory.projectadminfinal;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class EditProductCategoryController implements Initializable {

    @FXML private TextField idField;
    @FXML private TextField categoryNameField;
    @FXML private TextField descriptionField;

    @FXML private Label statusLabel;

    private ProductCategory productCategory;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Additional initialization if needed
    }

    public void initData(ProductCategory productCategory) {
        this.productCategory = productCategory;

        // Populate fields with existing product category data
        idField.setText(String.valueOf(productCategory.getCategoryID()));
        categoryNameField.setText(productCategory.getCategoryName());
        descriptionField.setText(productCategory.getCategoryDescription());
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (!validateInputs()) {
            return;
        }

        try {
            // Update product category object with form data
            productCategory.setCategoryName(categoryNameField.getText().trim());
            productCategory.setCategoryDescription(descriptionField.getText().trim());

            // Update product in database
            if (updateProductCategory()) {
                closeForm(event);
            }

        } catch (Exception e) {
            showErrorMessage("Error: " + e.getMessage());
        }
    }
    // Validates to check for empty fields
    private boolean validateInputs() {
        if (categoryNameField.getText().trim().isEmpty()) {
            showErrorMessage("Category Name is required");
            categoryNameField.requestFocus();
            return false;
        }

        if (descriptionField.getText().trim().isEmpty()) {
            showErrorMessage("Category Description is required");
            descriptionField.requestFocus();
            return false;
        }

        return true;
    }
    // Handles update of product category
    private boolean updateProductCategory() {
        String sql = "UPDATE Category SET CategoryName = ?, Description = ? WHERE CategoryID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, productCategory.getCategoryName());
            stmt.setString(2, productCategory.getCategoryDescription());
            stmt.setInt(3, productCategory.getCategoryID());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessMessage("Category updated successfully!");
                return true;
            } else {
                showErrorMessage("Failed to update category");
                return false;
            }

        } catch (SQLException e) {
            showErrorMessage("Database error: " + e.getMessage());
            return false;
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeForm(event);
    }

    private void closeForm(ActionEvent event) {
        // Get current stage and close it
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    private void showErrorMessage(String message) {
        statusLabel.setTextFill(Color.RED);
        statusLabel.setText("Error: " + message);
    }

    private void showSuccessMessage(String message) {
        statusLabel.setTextFill(Color.GREEN);
        statusLabel.setText(message);
    }
}