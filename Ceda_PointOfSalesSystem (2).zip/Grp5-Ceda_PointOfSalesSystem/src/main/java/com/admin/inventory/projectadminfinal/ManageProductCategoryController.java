package com.admin.inventory.projectadminfinal;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.Optional;
import java.util.ResourceBundle;

public class ManageProductCategoryController implements Initializable {

    @FXML private TableView<ProductCategory> productCategoryTable;
    @FXML private TableColumn<ProductCategory, Integer> idColumn;
    @FXML private TableColumn<ProductCategory, String> categoryNameColumn;
    @FXML private TableColumn<ProductCategory, String> descriptionColumn;

    @FXML private TextField searchField;
    @FXML private Button refreshButton;
    @FXML private Button addButton;
    @FXML private Button editButton;
    @FXML private Button archiveButton;
    @FXML private Label statusLabel;

    private ObservableList<ProductCategory> productCategories = FXCollections.observableArrayList();
    private FilteredList<ProductCategory> filteredProductCategory;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Initialize table columns
        idColumn.setCellValueFactory(new PropertyValueFactory<>("categoryID"));
        categoryNameColumn.setCellValueFactory(new PropertyValueFactory<>("categoryName"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("categoryDescription"));

        // Load categories from database
        loadCategories();

        // Set up filtered list for search functionality
        filteredProductCategory = new FilteredList<>(productCategories, p -> true);
        productCategoryTable.setItems(filteredProductCategory);

        // Enable/disable buttons based on selection
        productCategoryTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    boolean hasSelection = newValue != null;
                    editButton.setDisable(!hasSelection);
                    archiveButton.setDisable(!hasSelection);
                }
        );

        // Disables the buttons if there is no selected row
        editButton.setDisable(true);
        archiveButton.setDisable(true);
    }


     // Loads categories from the database

    private void loadCategories() {
        productCategories.clear();

        String sql = "SELECT * FROM Category ORDER BY CategoryID";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                ProductCategory category = new ProductCategory();
                category.setCategoryID(rs.getInt("CategoryID"));
                category.setCategoryName(rs.getString("CategoryName"));
                category.setCategoryDescription(rs.getString("Description"));

                productCategories.add(category);
            }

            statusLabel.setText("Loaded " + productCategories.size() + " categories");

        } catch (SQLException e) {
            showErrorMessage("Error loading categories: " + e.getMessage());
        }
    }

    @FXML
    private void handleRefresh() {
        loadCategories();
        searchField.clear();
        filteredProductCategory.setPredicate(p -> true); // Reset filter
    }
    // if the add new button is clicked, redirect the user to add new product category form
    @FXML
    private void handleAddNew() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/admin/inventory/projectadminfinal/AddProductCategory.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Add New Category");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);

            stage.showAndWait();

            // Refresh data after window is closed
            loadCategories();

        } catch (IOException e) {
            showErrorMessage("Error opening Add Category form: " + e.getMessage());
        }
    }

    @FXML
    private void handleEdit() {
        ProductCategory selectedProductCategory = productCategoryTable.getSelectionModel().getSelectedItem();
        if (selectedProductCategory == null) {
            showErrorMessage("Please select a category to edit");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/admin/inventory/projectadminfinal/EditProductCategory.fxml"));
            Parent root = loader.load();

            // Pass the selected category to the controller
            EditProductCategoryController controller = loader.getController();
            controller.initData(selectedProductCategory);

            Stage stage = new Stage();
            stage.setTitle("Edit Category");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);

            stage.showAndWait();

            // Refresh data after window is closed
            loadCategories();

        } catch (IOException e) {
            showErrorMessage("Error opening Edit Category form: " + e.getMessage());
        }
    }

    @FXML
    private void handleArchive() {
        ProductCategory selectedProductCategory = productCategoryTable.getSelectionModel().getSelectedItem();
        if (selectedProductCategory == null) {
            showErrorMessage("Please select a category to delete");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Category");
        alert.setHeaderText("Delete Category: " + selectedProductCategory.getCategoryName());
        alert.setContentText("Are you sure you want to delete this category?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            deleteCategory(selectedProductCategory.getCategoryID());
        }
    }
    // if ever the user wants to delete the selected category
    private void deleteCategory(int categoryId) {
        String sql = "DELETE FROM Category WHERE CategoryID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, categoryId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessMessage("Category successfully deleted");
                loadCategories(); // Refresh table
            } else {
                showErrorMessage("Failed to delete category");
            }

        } catch (SQLException e) {
            showErrorMessage("Database error: " + e.getMessage());
        }
    }
    //error and success message
    private void showErrorMessage(String message) {
        statusLabel.setTextFill(Color.RED);
        statusLabel.setText("Error: " + message);
    }

    private void showSuccessMessage(String message) {
        statusLabel.setTextFill(Color.GREEN);
        statusLabel.setText(message);
    }
}