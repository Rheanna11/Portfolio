package com.admin.inventory.projectadminfinal;

// HANDLES THE TRANSACTION HISTORY TABLE AND ALL THE BUTTONS ASSOCIATED WITH IT IN THE FXML FILE

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;

public class TransactionHistoryController implements Initializable {

    @FXML private TableView<Transactions> transactionTable;
    @FXML private TableColumn<Transactions, Integer> idColumn;
    @FXML private TableColumn<Transactions, String> orderID; // Changed to match FXML
    @FXML private TableColumn<Transactions, String> productID; // Changed to match FXML
    @FXML private TableColumn<Transactions, String> quantitySold; // Changed to match FXML
    @FXML private TableColumn<Transactions, String> unitPrice; // Changed to match FXML
    @FXML private TableColumn<Transactions, LocalDate> totalPrice; // Changed to match FXML
    @FXML private TableColumn<Transactions, String> employeeID; // Changed to match FXML

    @FXML private TextField searchField;
    @FXML private Button searchButton;
    @FXML private Button refreshButton;
    @FXML private Button editButton;
    @FXML private Button archiveButton;
    @FXML private Button exportButton; // for PDF export of transaction history
    @FXML private Label statusLabel;

    private ObservableList<Transactions> Transaction = FXCollections.observableArrayList();
    private FilteredList<Transactions> filteredTransaction;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Initialize table columns
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        orderID.setCellValueFactory(new PropertyValueFactory<>("transactionID"));
        productID.setCellValueFactory(new PropertyValueFactory<>("productID"));
        quantitySold.setCellValueFactory(new PropertyValueFactory<>("quantitySold"));
        unitPrice.setCellValueFactory(new PropertyValueFactory<>("unitPrice"));
        totalPrice.setCellValueFactory(new PropertyValueFactory<>("total_Price_Line"));
        employeeID.setCellValueFactory(new PropertyValueFactory<>("employeeID"));

        // Load transactions from database
        loadTransactions();

        // Set up filtered list for search functionality
        filteredTransaction = new FilteredList<>(Transaction, p -> true);
        transactionTable.setItems(filteredTransaction);

        // Enable/disable buttons based on selection
        transactionTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    boolean hasSelection = newValue != null;
                    editButton.setDisable(!hasSelection);
                    archiveButton.setDisable(!hasSelection);
                }
        );

        // Initially disable buttons until a row is selected
        editButton.setDisable(true);
    }


     // Loads transaction history from the database
    private void loadTransactions() { // Renamed for clarity
        Transaction.clear();

        // Fixed JOIN syntax
        String sql = "SELECT * FROM Sales_Line sl JOIN Sales s ON sl.transactionID = s.transactionID ORDER BY Sales_LineID";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Transactions transactions = new Transactions();
                transactions.setId(rs.getInt("Sales_LineID"));
                transactions.setTransactionID(rs.getInt("TransactionID"));
                transactions.setQuantitySold(rs.getInt("Quantity_Sold"));
                transactions.setUnitPrice(rs.getInt("Unit_Price"));
                transactions.setTotal_Price_Line(rs.getInt("Total_Line_Price"));
                transactions.setProductID(rs.getInt("ProductID"));
                transactions.setEmployeeID(rs.getInt("EmployeeID"));

                Transaction.add(transactions);
            }

            statusLabel.setText("Loaded " + Transaction.size() + " transactions");

        } catch (SQLException e) {
            showErrorMessage("Error loading transactions: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearch() {
        String searchText = searchField.getText().toLowerCase().trim();

        if (searchText.isEmpty()) {
            filteredTransaction.setPredicate(p -> true); // Show all if search is empty
        } else {
            filteredTransaction.setPredicate(transaction -> {
                // Match by transaction ID
                return String.valueOf(transaction.getId()).contains(searchText);
            });
        }

        statusLabel.setText("Found " + filteredTransaction.size() + " matching transactions");
    }

    @FXML
    private void handleRefresh() {
        loadTransactions();
        searchField.clear();
        filteredTransaction.setPredicate(p -> true); // Reset filter
    }

    @FXML
    private void handleDelete() {
        Transactions selectedTransactions = transactionTable.getSelectionModel().getSelectedItem();
        if (selectedTransactions == null) {
            showErrorMessage("Please select a category to delete");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Transaction");
        alert.setHeaderText("Delete Transaction: " + selectedTransactions.getTransactionID());
        alert.setContentText("Are you sure you want to delete this transaction?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            deleteTransaction(selectedTransactions.getTransactionID());
        }
    }

    private void deleteTransaction(int categoryId) {
        String sql = "DELETE FROM Sales_Line WHERE transactionID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, categoryId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessMessage("Transaction successfully deleted");
                loadTransactions(); // Refresh table
            } else {
                showErrorMessage("Failed to delete category");
            }

        } catch (SQLException e) {
            showErrorMessage("Database error: " + e.getMessage());
        }
    }


    @FXML
    private void handleClear() {
        Transactions selectedTransaction = transactionTable.getSelectionModel().getSelectedItem();
        if (selectedTransaction != null) {
            // You could implement archive functionality here
            showSuccessMessage("Archive functionality not yet implemented");
        }
    }

    @FXML
    private void handleExportToPDF() {
        try {
            // Create file chooser for saving PDF
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save Transaction History PDF");
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
            fileChooser.setInitialFileName("Transaction_History.pdf");

            // Show save dialog
            File file = fileChooser.showSaveDialog(exportButton.getScene().getWindow());

            if (file != null) {
                exportTableToPDF(file);
                showSuccessMessage("Transaction history exported to PDF successfully!");
            }
        } catch (Exception e) {
            showErrorMessage("Error exporting to PDF: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Exports the current table data to a PDF file
     * @param file The file to save the PDF to
     */
    private void exportTableToPDF(File file) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4.rotate());
        PdfWriter.getInstance(document, new FileOutputStream(file));

        document.open();

        // Add title
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
        Paragraph title = new Paragraph("CEDA AutoParts Transaction Report", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);

        // Add date
        Font dateFont = FontFactory.getFont(FontFactory.HELVETICA, 12);
        Paragraph date = new Paragraph("Generated on: " + java.time.LocalDate.now().toString(), dateFont);
        date.setAlignment(Element.ALIGN_RIGHT);
        document.add(date);

        document.add(new Paragraph(" ")); // Add empty space

        // Create table
        PdfPTable pdfTable = new PdfPTable(7); // 7 columns
        pdfTable.setWidthPercentage(100);

        // Add headers
        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
        addTableHeader(pdfTable, headerFont);

        // Add data rows
        Font rowFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
        addTableData(pdfTable, rowFont);

        document.add(pdfTable);
        document.close();
    }

    // PDF's table header
    private void addTableHeader(PdfPTable table, Font font) {
        String[] headers = {
                "Transaction ID", "Order ID", "Product ID",
                "Quantity Sold", "Unit Price", "Total Price", "Employee ID"
        };

        for (String header : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(header, font));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            cell.setPadding(5);
            table.addCell(cell);
        }
    }

    // data rows for pdf
    private void addTableData(PdfPTable table, Font font) {
        // Get the filtered list (what user is currently seeing)
        for (Transactions transaction : filteredTransaction) {
            // Add each cell with data
            addCell(table, String.valueOf(transaction.getId()), font);
            addCell(table, String.valueOf(transaction.getTransactionID()), font);
            addCell(table, String.valueOf(transaction.getProductID()), font);
            addCell(table, String.valueOf(transaction.getQuantitySold()), font);
            addCell(table, String.valueOf(transaction.getUnitPrice()), font);
            addCell(table, String.valueOf(transaction.getTotal_Price_Line()), font);
            addCell(table, String.valueOf(transaction.getEmployeeID()), font);
        }
    }

    // helper method to add cell
    private void addCell(PdfPTable table, String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setPadding(4);
        table.addCell(cell);
    }
    // errors and success messages
    private void showErrorMessage(String message) {
        statusLabel.setTextFill(Color.RED);
        statusLabel.setText("Error: " + message);
    }

    private void showSuccessMessage(String message) {
        statusLabel.setTextFill(Color.GREEN);
        statusLabel.setText(message);
    }
}