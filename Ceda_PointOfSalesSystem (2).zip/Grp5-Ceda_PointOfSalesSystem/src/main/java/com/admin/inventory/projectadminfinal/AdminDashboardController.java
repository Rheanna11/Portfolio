package com.admin.inventory.projectadminfinal;

import com.admin.inventory.projectadminfinal.DatabaseConnection;
import com.admin.inventory.projectadminfinal.SceneManager;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class AdminDashboardController implements Initializable {

    @FXML private StackPane contentArea;
    @FXML private Button dashboardBtn;
    @FXML private Button addProductBtn;
    @FXML private Button manageProductsBtn;
    @FXML private Button addEmployeeBtn;
    @FXML private Button manageEmployeesBtn;
    @FXML private Button transactionHistoryBtn;
    @FXML private Button salesReportBtn;
    @FXML private Button logoutBtn;
    @FXML private Button manageCategoriesBtn;
    @FXML private Label totalProductsLabel;
    @FXML private Label totalEmployeesLabel;
    @FXML private Label todaySalesLabel;

    private SceneManager sceneManager;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        sceneManager = new SceneManager();
        loadDashboardData();
    }

    private void loadDashboardData() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            // Get total products
            String productQuery = "SELECT COUNT(*) FROM Product";
            try (PreparedStatement stmt = conn.prepareStatement(productQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    totalProductsLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Get total employees
            String employeeQuery = "SELECT COUNT(*) FROM Employee WHERE Status = 'Active'";
            try (PreparedStatement stmt = conn.prepareStatement(employeeQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    totalEmployeesLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Get today's sales
            String salesQuery = "SELECT SUM(Total_Amount) FROM Sales WHERE Transaction_Date = ?";
            try (PreparedStatement stmt = conn.prepareStatement(salesQuery)) {
                stmt.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        double todaySales = rs.getDouble(1);
                        todaySalesLabel.setText(String.format("$%.2f", todaySales));
                    }
                }
            }

        } catch (SQLException e) {
            showErrorAlert("Database Error", "Failed to load dashboard data: " + e.getMessage());
        }
    }

    @FXML
    private void handleDashboard() {
        refreshDashboard();
    }

    private void refreshDashboard() {
        // Show the default dashboard content
        loadDashboardData();
        contentArea.getChildren().clear();
        contentArea.getChildren().add(sceneManager.getScene("/com/admin/inventory/projectadminfinal/DashboardContent.fxml"));
    }
    // Sets the main screen into addProduct.fxml
    @FXML
    private void handleAddProduct() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(sceneManager.getScene("/com/admin/inventory/projectadminfinal/addProduct.fxml"));
    }
    // Sets the main screen into ManageProducts.fxml
    @FXML
    private void handleManageProducts() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(sceneManager.getScene("/com/admin/inventory/projectadminfinal/ManageProducts.fxml"));
    }
    // Sets the main screen into ManageProductCategory.fxml
    @FXML
    private void handleManageProductCategory() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(sceneManager.getScene("/com/admin/inventory/projectadminfinal/ManageProductCategory.fxml"));
    }
    // Sets the main screen into addEmployee.fxml
    @FXML
    private void handleAddEmployee() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(sceneManager.getScene("/com/admin/inventory/projectadminfinal/addEmployee.fxml"));
    }
    // Sets the main screen into ManageEmployees.fxml
    @FXML
    private void handleManageEmployees() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(sceneManager.getScene("/com/admin/inventory/projectadminfinal/ManageEmployees.fxml"));
    }
    // Sets the main screen into TransactionHistory.fxml
    @FXML
    private void handleTransactionHistory() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(sceneManager.getScene("/com/admin/inventory/projectadminfinal/TransactionHistory.fxml"));
    }
    // Sets the main screen into TransactionHistory.fxml
    @FXML
    private void handleSalesReport() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(sceneManager.getScene("/com/admin/inventory/projectadminfinal/SalesReport.fxml"));
    }

    @FXML
    private void handleLogout() {
        try {
            DatabaseConnection.closeConnection();
            Stage stage = (Stage) logoutBtn.getScene().getWindow();
            new MainLogin().start(new Stage());
            stage.close();
        } catch (Exception e) {
            showErrorAlert("Error", "Error closing application: " + e.getMessage());
        }
    }


    private void showErrorAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}