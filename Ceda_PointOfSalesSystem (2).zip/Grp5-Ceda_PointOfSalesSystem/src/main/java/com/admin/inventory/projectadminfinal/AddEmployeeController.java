package com.admin.inventory.projectadminfinal;

import com.admin.inventory.projectadminfinal.Employee;
import com.admin.inventory.projectadminfinal.DatabaseConnection;
import com.admin.inventory.projectadminfinal.ValidationUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.paint.Color;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class AddEmployeeController implements Initializable {

    @FXML private TextField firstNameField;
    @FXML private TextField middleNameField;
    @FXML private TextField lastNameField;
    @FXML private ToggleGroup sexGroup;
    @FXML private RadioButton maleRadio;
    @FXML private RadioButton femaleRadio;
    @FXML private DatePicker hireDatePicker;
    @FXML private ComboBox<String> employeeTypeComboBox;
    @FXML private ComboBox<String> roleComboBox;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private ComboBox<String> statusComboBox;
    @FXML private Label statusLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Set today's date as default for the date picker
        hireDatePicker.setValue(LocalDate.now());

        // Load employee types from database
        loadEmployeeTypes();

        roleComboBox.setItems(FXCollections.observableArrayList(
                "Admin", "Staff"));

        statusComboBox.setItems(FXCollections.observableArrayList(
                "Active", "Inactive"));

        // Set default values for other combo boxes
        roleComboBox.setValue("Admin");
        statusComboBox.setValue("Active");
    }

    //loads employee types for table
    private void loadEmployeeTypes() {
        String sql = "SELECT Employee_Type FROM Employee_Type ORDER BY Employee_Type";
        ObservableList<String> employeeTypes = FXCollections.observableArrayList();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                employeeTypes.add(rs.getString("Employee_Type"));
            }

            employeeTypeComboBox.setItems(employeeTypes);

            if (!employeeTypes.isEmpty()) {
                employeeTypeComboBox.setValue(employeeTypes.get(0));
            }

        } catch (SQLException e) {
            showErrorMessage("Error loading employee types: " + e.getMessage());
        }
    }

    @FXML
    private void handleSave() {
        statusLabel.setText("");

        if (!validateInputs()) {
            return;
        }
        // Create Employee object from form data
        try {

            Employee employee = new Employee();
            employee.setFirstName(firstNameField.getText().trim());
            employee.setMiddleName(middleNameField.getText().trim());
            employee.setLastName(lastNameField.getText().trim());
            employee.setSex(maleRadio.isSelected() ? "M" : "F");
            employee.setHireDate(hireDatePicker.getValue());
            employee.setEmployeeType(employeeTypeComboBox.getValue());
            employee.setRole(roleComboBox.getValue());
            employee.setPassword(passwordField.getText());
            employee.setStatus(statusComboBox.getValue());

            // Save to database
            saveEmployee(employee);

        } catch (Exception e) {
            showErrorMessage("Error: " + e.getMessage());
        }
    }
    // input validation for empty fields
    private boolean validateInputs() {

        if (ValidationUtils.isEmpty(firstNameField.getText())) {
            showErrorMessage("First Name is required");
            firstNameField.requestFocus();
            return false;
        }

        if (ValidationUtils.isEmpty(lastNameField.getText())) {
            showErrorMessage("Last Name is required");
            lastNameField.requestFocus();
            return false;
        }

        if (hireDatePicker.getValue() == null) {
            showErrorMessage("Hire Date is required");
            hireDatePicker.requestFocus();
            return false;
        }

        if (employeeTypeComboBox.getValue() == null) {
            showErrorMessage("Employee Type is required");
            employeeTypeComboBox.requestFocus();
            return false;
        }

        if (roleComboBox.getValue() == null) {
            showErrorMessage("Role is required");
            roleComboBox.requestFocus();
            return false;
        }

        if (ValidationUtils.isEmpty(passwordField.getText())) {
            showErrorMessage("Password is required");
            passwordField.requestFocus();
            return false;
        }

        if (ValidationUtils.isEmpty(confirmPasswordField.getText())) {
            showErrorMessage("Please confirm your password");
            confirmPasswordField.requestFocus();
            return false;
        }

        if (!passwordField.getText().equals(confirmPasswordField.getText())) {
            showErrorMessage("Passwords do not match");
            confirmPasswordField.requestFocus();
            return false;
        }

        if (statusComboBox.getValue() == null) {
            showErrorMessage("Status is required");
            statusComboBox.requestFocus();
            return false;
        }

        return true;
    }
    //handles user input for database insertion
    private void saveEmployee(Employee employee) {
        String sql = "INSERT INTO Employee ( First_Name, Middle_Name, Last_Name, " +
                "Sex, Hire_Date, Employee_Type, ROLE, Password, Status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, employee.getFirstName());
            stmt.setString(2, employee.getMiddleName());
            stmt.setString(3, employee.getLastName());
            stmt.setString(4, employee.getSex());
            stmt.setDate(5, java.sql.Date.valueOf(employee.getHireDate()));
            stmt.setString(6, employee.getEmployeeType());
            stmt.setString(7, employee.getRole());
            stmt.setString(8, employee.getPassword());
            stmt.setString(9, employee.getStatus());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessMessage("Employee added successfully!");
                clearFields();
            } else {
                showErrorMessage("Failed to add employee");
            }

        } catch (SQLException e) {
            // IF only the id input is similar to existing ID will this erro message show.
            if (e.getErrorCode() == 1062) {
                showErrorMessage("An employee with this ID already exists");
            } else {
                showErrorMessage("Database error: " + e.getMessage());
            }
        } catch (Exception e) {
            showErrorMessage("Error: " + e.getMessage());
        }
    }

    @FXML
    private void handleClear() {
        clearFields();
        statusLabel.setText("");
    }

    private void clearFields() {
        firstNameField.clear();
        middleNameField.clear();
        lastNameField.clear();
        maleRadio.setSelected(true);
        hireDatePicker.setValue(LocalDate.now());

        // Set the first employee type in the list as default (if available)
        if (employeeTypeComboBox.getItems().size() > 0) {
            employeeTypeComboBox.setValue(employeeTypeComboBox.getItems().get(0));
        }

        roleComboBox.setValue("Admin");
        passwordField.clear();
        confirmPasswordField.clear();
        statusComboBox.setValue("Active");
    }

    private void showErrorMessage(String message) {
        statusLabel.setTextFill(Color.RED);
        statusLabel.setText("Error: " + message);
    }

    private void showSuccessMessage(String message) {
        statusLabel.setTextFill(Color.GREEN);
        statusLabel.setText(message);
    }
}