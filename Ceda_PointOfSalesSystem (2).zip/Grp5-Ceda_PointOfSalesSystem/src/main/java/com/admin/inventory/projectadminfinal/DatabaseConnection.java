package com.admin.inventory.projectadminfinal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

    // used for getting connection
public class DatabaseConnection {
    private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=CEDA;integratedSecurity=true;encrypt=true;trustServerCertificate=true";

    private static Connection connection = null;

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                connection = DriverManager.getConnection(URL);
                // to check if connection is still okay whenever the user switch pages
                System.out.println("Connected to the database!");
            } catch (ClassNotFoundException e) {
                System.out.println("SQL Server JDBC driver not found!");
                e.printStackTrace();
            }
        }
        return connection;
    }

    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed!");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}