package com.admin.inventory.projectadminfinal;

// THIS is a MODEL (container) for Product to be used on editing and adding products
// makes use of constructor and parameterized constructors

import javafx.beans.property.*;
import java.time.LocalDate;

public class Product {
    private final IntegerProperty productID;
    private final StringProperty productDescription;
    private final IntegerProperty productQuantity;
    private final DoubleProperty productPrice;
    private final StringProperty oeimd;
    private final IntegerProperty reorderLevel;
    private final ObjectProperty<LocalDate> lastRestockDate;
    private final StringProperty status;
    private final IntegerProperty categoryID;

    public Product() {
        this.productID = new SimpleIntegerProperty();
        this.productDescription = new SimpleStringProperty();
        this.productQuantity = new SimpleIntegerProperty();
        this.productPrice = new SimpleDoubleProperty();
        this.oeimd = new SimpleStringProperty();
        this.reorderLevel = new SimpleIntegerProperty();
        this.lastRestockDate = new SimpleObjectProperty<>();
        this.status = new SimpleStringProperty();
        this.categoryID = new SimpleIntegerProperty();
    }
    // setters and getters
    // ProductID
    public int getProductID() {
        return productID.get();
    }

    public void setProductID(int productID) {
        this.productID.set(productID);
    }

    public IntegerProperty productIDProperty() {
        return productID;
    }

    // Product Description
    public String getProductDescription() {
        return productDescription.get();
    }

    public void setProductDescription(String productDescription) {
        this.productDescription.set(productDescription);
    }

    public StringProperty productDescriptionProperty() {
        return productDescription;
    }

    // Product Quantity
    public int getProductQuantity() {
        return productQuantity.get();
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity.set(productQuantity);
    }

    public IntegerProperty productQuantityProperty() {
        return productQuantity;
    }

    // Product Price
    public double getProductPrice() {
        return productPrice.get();
    }

    public void setProductPrice(double productPrice) {
        this.productPrice.set(productPrice);
    }

    public DoubleProperty productPriceProperty() {
        return productPrice;
    }

    // OEIMD
    public String getOeimd() {
        return oeimd.get();
    }

    public void setOeimd(String oeimd) {
        this.oeimd.set(oeimd);
    }

    public StringProperty oeimdProperty() {
        return oeimd;
    }

    // Reorder Level
    public int getReorderLevel() {
        return reorderLevel.get();
    }

    public void setReorderLevel(int reorderLevel) {
        this.reorderLevel.set(reorderLevel);
    }

    public IntegerProperty reorderLevelProperty() {
        return reorderLevel;
    }

    // Last Restock Date
    public LocalDate getLastRestockDate() {
        return lastRestockDate.get();
    }

    public void setLastRestockDate(LocalDate lastRestockDate) {
        this.lastRestockDate.set(lastRestockDate);
    }

    public ObjectProperty<LocalDate> lastRestockDateProperty() {
        return lastRestockDate;
    }

    // Status
    public String getStatus() {
        return status.get();
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    public StringProperty statusProperty() {
        return status;
    }

    @Override
    public String toString() {
        return productDescription.get();
    }

    public int getCategoryID() {
        return categoryID.get();
    }

    public void setCategoryID(int categoryID) {
        this.categoryID.set(categoryID);
    }

    public IntegerProperty categoryIDProperty() {
        return categoryID;
    }
}