package com.admin.inventory.projectadminfinal;

import com.admin.inventory.projectadminfinal.Product;
import com.admin.inventory.projectadminfinal.DatabaseConnection;
import com.admin.inventory.projectadminfinal.ValidationUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.paint.Color;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class AddProductController implements Initializable {

    @FXML private TextField descriptionField;
    @FXML private TextField quantityField;
    @FXML private TextField priceField;
    @FXML private TextField gemoField;
    @FXML private TextField reorderLevelField;
    @FXML private DatePicker lastRestockDatePicker;
    @FXML private ComboBox<Integer> categoryID;
    @FXML private Label statusLabel;
    @FXML private Button saveButton;
    @FXML private Button clearButton;


    // loads existing categories
    private void loadCategories() {
        String sql = "SELECT CategoryID FROM Category ORDER BY CategoryID";
        ObservableList<Integer> categories = FXCollections.observableArrayList();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                categories.add(rs.getInt("CategoryID"));
            }

            categoryID.setItems(categories);

            // Set default value if there are employee types available
            if (!categories.isEmpty()) {
                categoryID.setValue(categories.get(0));
            }

        } catch (SQLException e) {
            showErrorMessage("Error loading employee types: " + e.getMessage());
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        loadCategories();
        lastRestockDatePicker.setValue(LocalDate.now());

        quantityField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                quantityField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        priceField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*\\.?\\d*")) {
                priceField.setText(oldValue);
            }
        });

        reorderLevelField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                reorderLevelField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }
    // method for save button
    @FXML
    private void handleSave() {
        statusLabel.setText("");

        // Validate inputs
        if (!validateInputs()) {
            return;
        }
        // If no empty field/s, create Product object from form data
        try {
            Product product = new Product();
            product.setProductDescription(descriptionField.getText().trim());
            product.setProductQuantity(Integer.parseInt(quantityField.getText().trim()));
            product.setProductPrice(Double.parseDouble(priceField.getText().trim()));
            product.setOeimd(gemoField.getText().trim());
            product.setReorderLevel(Integer.parseInt(reorderLevelField.getText().trim()));
            product.setLastRestockDate(lastRestockDatePicker.getValue());
            product.setCategoryID(categoryID.getValue());

            // Save to database
            saveProduct(product);

        } catch (NumberFormatException e) {
            showErrorMessage("Invalid number format: " + e.getMessage());
        } catch (Exception e) {
            showErrorMessage("Error: " + e.getMessage());
        }
    }
    // Validation to check for empty fields
    private boolean validateInputs() {

        if (descriptionField.getText().trim().isEmpty()) {
            showErrorMessage("Product Description is required");
            descriptionField.requestFocus();
            return false;
        }

        if (quantityField.getText().trim().isEmpty()) {
            showErrorMessage("Quantity is required");
            quantityField.requestFocus();
            return false;
        }

        if (priceField.getText().trim().isEmpty()) {
            showErrorMessage("Price is required");
            priceField.requestFocus();
            return false;
        }

        if (gemoField.getText().trim().isEmpty()) {
            showErrorMessage("OEIMD is required");
            gemoField.requestFocus();
            return false;
        }

        if (reorderLevelField.getText().trim().isEmpty()) {
            showErrorMessage("Reorder Level is required");
            reorderLevelField.requestFocus();
            return false;
        }

        if (lastRestockDatePicker.getValue() == null) {
            showErrorMessage("Last Restock Date is required");
            lastRestockDatePicker.requestFocus();
            return false;
        }

        return true;
    }
    // handles save button && database insertion
    private void saveProduct(Product product) {
        String sql = "INSERT INTO Product (Product_Description, Product_Quantity, " +
                "Product_Price, OEIMD, Reorder_Level, Last_Restock_Date) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, product.getProductDescription());
            stmt.setInt(2, product.getProductQuantity());
            stmt.setDouble(3, product.getProductPrice());
            stmt.setString(4, product.getOeimd());
            stmt.setInt(5, product.getReorderLevel());
            stmt.setDate(6, java.sql.Date.valueOf(product.getLastRestockDate()));

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessMessage("Product added successfully!");
                clearFields();
            } else {
                showErrorMessage("Failed to add product");
            }

        } catch (SQLException e) {
            // Check for duplicate key error (MySQL error code 1062)
            if (e.getErrorCode() == 1062) {
                showErrorMessage("A product with this ID already exists");
            } else {
                showErrorMessage("Database error: " + e.getMessage());
            }
        } catch (Exception e) {
            showErrorMessage("Error: " + e.getMessage());
        }
    }

    @FXML
    private void handleClear() {
        clearFields();
        statusLabel.setText("");
    }

    private void clearFields() {
        descriptionField.clear();
        quantityField.clear();
        priceField.clear();
        gemoField.clear();
        reorderLevelField.clear();
        lastRestockDatePicker.setValue(LocalDate.now());
    }

    private void showErrorMessage(String message) {
        statusLabel.setTextFill(Color.RED);
        statusLabel.setText("Error: " + message);
    }

    private void showSuccessMessage(String message) {
        statusLabel.setTextFill(Color.GREEN);
        statusLabel.setText(message);
    }
}