package com.admin.inventory.projectadminfinal;

public class OrderItem {
    private int productId;
    private String productDescription;
    private int quantity;
    private double unitPrice;
    private double totalPrice;

    public OrderItem(int productId, String productDescription, int quantity, double unitPrice, double totalPrice) {
        this.productId = productId;
        this.productDescription = productDescription;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.totalPrice = totalPrice;
    }

    // Getters
    public int getProductId() {
        return productId;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    // Setters for updating quantity and total price
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    // Additional method to increment quantity
    public void incrementQuantity(int additionalQuantity) {
        this.quantity += additionalQuantity;
        this.totalPrice = this.quantity * this.unitPrice;
    }
}