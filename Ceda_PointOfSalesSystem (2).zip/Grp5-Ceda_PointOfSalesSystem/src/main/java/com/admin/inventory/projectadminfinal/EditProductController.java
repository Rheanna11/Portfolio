package com.admin.inventory.projectadminfinal;

// CONTROLLER FOR EDITING PRODUCT

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.paint.Paint;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class EditProductController implements Initializable {

    @FXML private TextField idField;
    @FXML private TextField descriptionField;
    @FXML private TextField quantityField;
    @FXML private TextField priceField;
    @FXML private TextField oeimdField;
    @FXML private TextField reorderLevelField;
    @FXML private DatePicker lastRestockDatePicker;
    @FXML private Label statusLabel;

    private Product product;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Additional initialization if needed
    }


     // Initializes the form with product data
    public void initData(Product product) {
        this.product = product;

        // Populate fields with product data
        idField.setText(String.valueOf(product.getProductID()));
        descriptionField.setText(product.getProductDescription());
        quantityField.setText(String.valueOf(product.getProductQuantity()));
        priceField.setText(String.valueOf(product.getProductPrice()));
        oeimdField.setText(product.getOeimd());
        reorderLevelField.setText(String.valueOf(product.getReorderLevel()));
        lastRestockDatePicker.setValue(product.getLastRestockDate());
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (!validateInputs()) {
            return;
        }
        // Update product object with form data
        try {
            product.setProductDescription(descriptionField.getText().trim());
            product.setProductQuantity(Integer.parseInt(quantityField.getText().trim()));
            product.setProductPrice(Double.parseDouble(priceField.getText().trim()));
            product.setOeimd(oeimdField.getText().trim());
            product.setReorderLevel(Integer.parseInt(reorderLevelField.getText().trim()));
            product.setLastRestockDate(lastRestockDatePicker.getValue());

            // Update product in database
            if (updateProduct()) {
                closeForm(event);
            }

        } catch (NumberFormatException e) {
            showErrorMessage("Please enter valid numbers for quantity, price, and reorder level");
        } catch (Exception e) {
            showErrorMessage("Error: " + e.getMessage());
        }
    }
    // Validate inputs to check for empty fields
    private boolean validateInputs() {

        if (descriptionField.getText().trim().isEmpty()) {
            showErrorMessage("Product Description is required");
            descriptionField.requestFocus();
            return false;
        }

        if (quantityField.getText().trim().isEmpty()) {
            showErrorMessage("Product Quantity is required");
            quantityField.requestFocus();
            return false;
        }

        if (priceField.getText().trim().isEmpty()) {
            showErrorMessage("Product Price is required");
            priceField.requestFocus();
            return false;
        }

        if (oeimdField.getText().trim().isEmpty()) {
            showErrorMessage("OEIMD is required");
            oeimdField.requestFocus();
            return false;
        }

        if (reorderLevelField.getText().trim().isEmpty()) {
            showErrorMessage("Reorder Level is required");
            reorderLevelField.requestFocus();
            return false;
        }

        if (lastRestockDatePicker.getValue() == null) {
            showErrorMessage("Last Restock Date is required");
            lastRestockDatePicker.requestFocus();
            return false;
        }

        // Validate numeric fields
        try {
            Integer.parseInt(quantityField.getText().trim());
        } catch (NumberFormatException e) {
            showErrorMessage("Product Quantity must be a number");
            quantityField.requestFocus();
            return false;
        }

        try {
            Double.parseDouble(priceField.getText().trim());
        } catch (NumberFormatException e) {
            showErrorMessage("Product Price must be a number");
            priceField.requestFocus();
            return false;
        }

        try {
            Integer.parseInt(reorderLevelField.getText().trim());
        } catch (NumberFormatException e) {
            showErrorMessage("Reorder Level must be a number");
            reorderLevelField.requestFocus();
            return false;
        }

        return true;
    }
    // Handles updating of product in the database
    private boolean updateProduct() {
        String sql = "UPDATE Product SET Product_Description = ?, Product_Quantity = ?, " +
                "Product_Price = ?, OEIMD = ?, Reorder_Level = ?, Last_Restock_Date = ? " +
                "WHERE ProductID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, product.getProductDescription());
            stmt.setInt(2, product.getProductQuantity());
            stmt.setDouble(3, product.getProductPrice());
            stmt.setString(4, product.getOeimd());
            stmt.setInt(5, product.getReorderLevel());
            stmt.setDate(6, java.sql.Date.valueOf(product.getLastRestockDate()));
            stmt.setInt(7, product.getProductID());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessMessage("Product updated successfully!");
                return true;
            } else {
                showErrorMessage("Failed to update product");
                return false;
            }

        } catch (SQLException e) {
            showErrorMessage("Database error: " + e.getMessage());
            return false;
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeForm(event);
    }

    private void closeForm(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
    // Error or Success Message for user's action
    private void showErrorMessage(String message) {
        if (statusLabel != null) {
            statusLabel.setTextFill(Color.RED);
            statusLabel.setText("Error: " + message);
        }
    }


    private void showSuccessMessage(String message) {
        if (statusLabel != null) {
            statusLabel.setTextFill(Color.GREEN);
            statusLabel.setText(message);
        }
    }
}