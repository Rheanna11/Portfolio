package com.admin.inventory.projectadminfinal;

// HANDLES THE GENERATION OF RECEIPT

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.UnitValue;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ReceiptGenerator {

    public static void showReceipt(Stage ownerStage, String currentUser, ObservableList<OrderItem> cartItems,
                                   double totalAmount, int orderId, double cashAmount, double change) {
        // receipt string
        StringBuilder receipt = new StringBuilder();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        receipt.append("CEDA AUTO SUPPLY\n");
        receipt.append("City of Malolos, Bulacan\n09707352753\n");
        receipt.append("------ RECEIPT ------\n\n");
        receipt.append("Order #: ").append(orderId).append("\n");
        receipt.append("Date: ").append(dateFormat.format(new Date())).append("\n");
        receipt.append("Cashier: ").append(currentUser).append("\n\n");

        receipt.append(String.format("%-25s %-5s %-10s %-10s\n", "ITEM", "QTY", "PRICE", "TOTAL"));
        for (OrderItem item : cartItems) {
            receipt.append(String.format("%-25s %-5d P%-9.2f P%-9.2f\n",
                    item.getProductDescription(),
                    item.getQuantity(),
                    item.getUnitPrice(),
                    item.getTotalPrice()));
        }

        receipt.append("\n");
        receipt.append(String.format("Subtotal: P%.2f\n", totalAmount));
        receipt.append(String.format("Cash:     P%.2f\n", cashAmount));
        receipt.append(String.format("Change:   P%.2f\n", change));
        receipt.append("\nThank you for your purchase! Please balik po kayo!");

        // receipt view dialog
        TextArea previewArea = new TextArea(receipt.toString());
        previewArea.setEditable(false);
        previewArea.setWrapText(true);

        Alert previewAlert = new Alert(Alert.AlertType.CONFIRMATION);
        previewAlert.initOwner(ownerStage);
        previewAlert.setTitle("Receipt Preview");
        previewAlert.setHeaderText("Preview of the Receipt");
        previewAlert.getDialogPane().setContent(new VBox(previewArea));

        ButtonType downloadBtn = new ButtonType("Download PDF", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelBtn = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        previewAlert.getButtonTypes().setAll(downloadBtn, cancelBtn);

        previewAlert.showAndWait().ifPresent(response -> {
            if (response == downloadBtn) {
                //  download pdf
                savePdf(ownerStage, receipt.toString(), cartItems, totalAmount, orderId, cashAmount, change, currentUser);
            }
        });
    }

    private static void savePdf(Stage ownerStage, String receipt, ObservableList<OrderItem> cartItems,
                                double totalAmount, int orderId, double cashAmount, double change, String currentUser) {
        try {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save Receipt as PDF");
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
            fileChooser.setInitialFileName("CEDAReceipt_" + orderId + ".pdf");
            File file = fileChooser.showSaveDialog(ownerStage);
            if (file == null) return;

            PdfWriter writer = new PdfWriter(file);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            PdfFont font = PdfFontFactory.createFont(StandardFonts.HELVETICA);
            PdfFont boldFont = PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD);

            document.add(new Paragraph("CEDA AUTO SUPPLY").setFont(boldFont).setFontSize(18));
            document.add(new Paragraph("City of Malolos, Bulacan\n09707352753").setFont(font));
            document.add(new Paragraph("\n------ RECEIPT ------\n").setFont(boldFont).setFontSize(14));

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            document.add(new Paragraph("Order #: " + orderId).setFont(font));
            document.add(new Paragraph("Date: " + dateFormat.format(new Date())).setFont(font));
            document.add(new Paragraph("Cashier: " + currentUser).setFont(font));
            document.add(new Paragraph("\n"));

            Table table = new Table(UnitValue.createPercentArray(new float[]{50, 15, 20, 20}))
                    .setWidth(UnitValue.createPercentValue(100));
            table.addHeaderCell(new Paragraph("ITEM").setFont(boldFont));
            table.addHeaderCell(new Paragraph("QTY").setFont(boldFont));
            table.addHeaderCell(new Paragraph("PRICE").setFont(boldFont));
            table.addHeaderCell(new Paragraph("TOTAL").setFont(boldFont));

            for (OrderItem item : cartItems) {
                table.addCell(new Paragraph(item.getProductDescription()).setFont(font));
                table.addCell(new Paragraph(String.valueOf(item.getQuantity())).setFont(font));
                table.addCell(new Paragraph(String.format("P%.2f", item.getUnitPrice())).setFont(font));
                table.addCell(new Paragraph(String.format("P%.2f", item.getTotalPrice())).setFont(font));
            }

            document.add(table);
            document.add(new Paragraph("\n"));
            document.add(new Paragraph(String.format("Subtotal: P%.2f", totalAmount)).setFont(font));
            document.add(new Paragraph(String.format("Cash: P%.2f", cashAmount)).setFont(font));
            document.add(new Paragraph(String.format("Change: P%.2f", change)).setFont(boldFont));
            document.add(new Paragraph("\nThank you for your purchase! Please balik po kayo!").setFont(font));
            document.close();


            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("PDF Saved");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Receipt PDF has been saved and opened successfully.");
            successAlert.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setTitle("PDF Error");
            errorAlert.setHeaderText("Failed to save PDF");
            errorAlert.setContentText("Error: " + e.getMessage());
            errorAlert.showAndWait();
        }
    }
}