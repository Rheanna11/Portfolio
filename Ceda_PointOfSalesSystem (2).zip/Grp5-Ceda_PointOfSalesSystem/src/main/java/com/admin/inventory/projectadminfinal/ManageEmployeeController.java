package com.admin.inventory.projectadminfinal;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;

public class ManageEmployeeController implements Initializable {

    @FXML private TableView<Employee> employeeTable;
    @FXML private TableColumn<Employee, Integer> idColumn;
    @FXML private TableColumn<Employee, String> firstNameColumn;
    @FXML private TableColumn<Employee, String> middleNameColumn;
    @FXML private TableColumn<Employee, String> lastNameColumn;
    @FXML private TableColumn<Employee, String> sexColumn;
    @FXML private TableColumn<Employee, LocalDate> hireDateColumn;
    @FXML private TableColumn<Employee, String> employeeTypeColumn;
    @FXML private TableColumn<Employee, String> roleColumn;

    @FXML private TextField searchField;
    @FXML private Button searchButton;
    @FXML private Button refreshButton;
    @FXML private Button addButton;
    @FXML private Button editButton;
    @FXML private Button archiveButton;
    @FXML private Label statusLabel;

    private ObservableList<Employee> employeeList = FXCollections.observableArrayList();
    private FilteredList<Employee> filteredEmployees;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Initialize table columns
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        middleNameColumn.setCellValueFactory(new PropertyValueFactory<>("middleName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        sexColumn.setCellValueFactory(new PropertyValueFactory<>("sex"));
        hireDateColumn.setCellValueFactory(new PropertyValueFactory<>("hireDate"));
        employeeTypeColumn.setCellValueFactory(new PropertyValueFactory<>("employeeType"));
        roleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));

        // Load employees from database
        loadEmployees();

        // Set up filtered list for search functionality
        filteredEmployees = new FilteredList<>(employeeList, p -> true);
        employeeTable.setItems(filteredEmployees);

        employeeTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    boolean hasSelection = newValue != null;
                    editButton.setDisable(!hasSelection);
                    archiveButton.setDisable(!hasSelection);
                }
        );

        // Initially disable buttons until a row is selected
        editButton.setDisable(true);
        archiveButton.setDisable(true);
    }

    // Loads al the ACTIVE Employees only
    private void loadEmployees() {
        employeeList.clear();

        String sql = "SELECT * FROM Employee WHERE Status = 'Active' ORDER BY EmployeeID";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Employee employee = new Employee();
                employee.setId(rs.getInt("EmployeeID"));
                employee.setFirstName(rs.getString("First_Name"));
                employee.setMiddleName(rs.getString("Middle_Name"));
                employee.setLastName(rs.getString("Last_Name"));
                employee.setSex(rs.getString("Sex"));

                // Convert SQL date to LocalDate
                Date sqlDate = rs.getDate("Hire_Date");
                if (sqlDate != null) {
                    employee.setHireDate(sqlDate.toLocalDate());
                }

                employee.setEmployeeType(rs.getString("Employee_Type"));
                employee.setRole(rs.getString("Role"));
                employee.setStatus(rs.getString("Status"));

                employeeList.add(employee);
            }

            statusLabel.setText("Loaded " + employeeList.size() + " active employees");

        } catch (SQLException e) {
            showErrorMessage("Error loading employees: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearch() {
        String searchText = searchField.getText().toLowerCase().trim();

        if (searchText.isEmpty()) {
            filteredEmployees.setPredicate(p -> true); // Show all if search is empty
        } else {
            filteredEmployees.setPredicate(employee -> {
                // matches by name or Employee Id
                return String.valueOf(employee.getId()).contains(searchText) ||
                        employee.getFirstName().toLowerCase().contains(searchText) ||
                        (employee.getMiddleName() != null &&
                                employee.getMiddleName().toLowerCase().contains(searchText)) ||
                        employee.getLastName().toLowerCase().contains(searchText);
            });
        }

        statusLabel.setText("Found " + filteredEmployees.size() + " matching employees");
    }

    @FXML
    private void handleRefresh() {
        loadEmployees();
        searchField.clear();
        filteredEmployees.setPredicate(p -> true); // Reset filter
    }
    // IF 'Add New' button was clicked, it will open the AddEmployee.fxml
    @FXML
    private void handleAddNew() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/admin/inventory/projectadminfinal/AddEmployee.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Add New Employee");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL); // Block interaction with other windows

            stage.showAndWait();

            // Refresh data after window is closed
            loadEmployees();

        } catch (IOException e) {
            showErrorMessage("Error opening Add Employee form: " + e.getMessage());
        }
    }
    // Same with addNew, handles the editing of employees
    @FXML
    private void handleEdit() {
        Employee selectedEmployee = employeeTable.getSelectionModel().getSelectedItem();
        if (selectedEmployee == null) {
            showErrorMessage("Please select an employee to edit");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/admin/inventory/projectadminfinal/EditEmployee.fxml"));
            Parent root = loader.load();

            // Pass the selected employee to the controller
            EditEmployeeController controller = loader.getController();
            controller.initData(selectedEmployee);

            Stage stage = new Stage();
            stage.setTitle("Edit Employee");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);

            stage.showAndWait();

            // Refresh data after window is closed
            loadEmployees();

        } catch (IOException e) {
            showErrorMessage("Error opening Edit Employee form: " + e.getMessage());
        }
    }
    // method for the archive button
    @FXML
    private void handleArchive() {
        Employee selectedEmployee = employeeTable.getSelectionModel().getSelectedItem();
        if (selectedEmployee == null) {
            showErrorMessage("Please select an employee to archive");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Archive Employee");
        alert.setHeaderText("Archive Employee: " + selectedEmployee.getFirstName() + " " + selectedEmployee.getLastName());
        alert.setContentText("Are you sure you want to mark this employee as inactive?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            archiveEmployee(selectedEmployee.getId());
        }
    }
    // method to set the status of the selected employee into archive
    private void archiveEmployee(int employeeId) {
        String sql = "UPDATE Employee SET Status = 'Inactive' WHERE EmployeeID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, employeeId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessMessage("Employee successfully archived");
                loadEmployees(); // Refresh table
            } else {
                showErrorMessage("Failed to archive employee");
            }

        } catch (SQLException e) {
            showErrorMessage("Database error: " + e.getMessage());
        }
    }
    // errors and success message
    private void showErrorMessage(String message) {
        statusLabel.setTextFill(Color.RED);
        statusLabel.setText("Error: " + message);
    }

    private void showSuccessMessage(String message) {
        statusLabel.setTextFill(Color.GREEN);
        statusLabel.setText(message);
    }
}