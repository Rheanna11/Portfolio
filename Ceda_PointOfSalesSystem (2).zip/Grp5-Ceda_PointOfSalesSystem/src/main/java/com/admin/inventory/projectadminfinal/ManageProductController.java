package com.admin.inventory.projectadminfinal;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;

public class ManageProductController implements Initializable {

    @FXML private TableView<Product> productTable;
    @FXML private TableColumn<Product, Integer> idColumn;
    @FXML private TableColumn<Product, String> descriptionColumn;
    @FXML private TableColumn<Product, Integer> quantityColumn;
    @FXML private TableColumn<Product, Double> priceColumn;
    @FXML private TableColumn<Product, String> oeimdColumn;
    @FXML private TableColumn<Product, Integer> reorderLevelColumn;
    @FXML private TableColumn<Product, LocalDate> lastRestockDateColumn;

    @FXML private TextField searchField;
    @FXML private Button searchButton;
    @FXML private Button refreshButton;
    @FXML private Button addButton;
    @FXML private Button editButton;
    @FXML private Button archiveButton;
    @FXML private Label statusLabel;

    private ObservableList<Product> productList = FXCollections.observableArrayList();
    private FilteredList<Product> filteredProducts;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Initialize table columns
        idColumn.setCellValueFactory(new PropertyValueFactory<>("productID"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("productDescription"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("productQuantity"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("productPrice"));
        oeimdColumn.setCellValueFactory(new PropertyValueFactory<>("oeimd"));
        reorderLevelColumn.setCellValueFactory(new PropertyValueFactory<>("reorderLevel"));
        lastRestockDateColumn.setCellValueFactory(new PropertyValueFactory<>("lastRestockDate"));

        // Load products from database
        loadProducts();

        // Set up filtered list for search functionality
        filteredProducts = new FilteredList<>(productList, p -> true);
        productTable.setItems(filteredProducts);

        // Enable/disable buttons based on selection
        productTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    boolean hasSelection = newValue != null;
                    editButton.setDisable(!hasSelection);
                    archiveButton.setDisable(!hasSelection);
                }
        );

        // Initially disable buttons until a row is selected
        editButton.setDisable(true);
        archiveButton.setDisable(true);
    }

    // Loads product that are on the Product table
    private void loadProducts() {
        productList.clear();

        String sql = "SELECT * FROM Product ORDER BY ProductID";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Product product = new Product();
                product.setProductID(rs.getInt("ProductID"));
                product.setProductDescription(rs.getString("Product_Description"));
                product.setProductQuantity(rs.getInt("Product_Quantity"));
                product.setProductPrice(rs.getDouble("Product_Price"));
                product.setOeimd(rs.getString("OEIMD"));
                product.setReorderLevel(rs.getInt("Reorder_Level"));

                // Convert SQL date to LocalDate
                Date sqlDate = rs.getDate("Last_Restock_Date");
                if (sqlDate != null) {
                    product.setLastRestockDate(sqlDate.toLocalDate());
                }

                productList.add(product);
            }

            statusLabel.setText("Loaded " + productList.size() + " active products");

        } catch (SQLException e) {
            showErrorMessage("Error loading products: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearch() {
        String searchText = searchField.getText().toLowerCase().trim();

        if (searchText.isEmpty()) {
            filteredProducts.setPredicate(p -> true); // Show all if search is empty
        } else {
            filteredProducts.setPredicate(product -> {
                // Match by ID or description/name
                return String.valueOf(product.getProductID()).contains(searchText) ||
                        product.getProductDescription().toLowerCase().contains(searchText) ||
                        product.getOeimd().toLowerCase().contains(searchText);
            });
        }

        statusLabel.setText("Found " + filteredProducts.size() + " matching products");
    }

    @FXML
    private void handleRefresh() {
        loadProducts();
        searchField.clear();
        filteredProducts.setPredicate(p -> true);
    }

    @FXML
    private void handleAddNew() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/admin/inventory/projectadminfinal/AddProduct.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Add New Product");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);

            stage.showAndWait();

            // Refresh data after window is closed
            loadProducts();

        } catch (IOException e) {
            showErrorMessage("Error opening Add Product form: " + e.getMessage());
        }
    }

    @FXML
    private void handleEdit() {
        Product selectedProduct = productTable.getSelectionModel().getSelectedItem();
        if (selectedProduct == null) {
            showErrorMessage("Please select a product to edit");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/admin/inventory/projectadminfinal/EditProduct.fxml"));
            Parent root = loader.load();

            // Pass the selected product to the controller
            EditProductController controller = loader.getController();
            controller.initData(selectedProduct);

            Stage stage = new Stage();
            stage.setTitle("Edit Product");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);

            stage.showAndWait();

            // Refresh data after window is closed
            loadProducts();

        } catch (IOException e) {
            showErrorMessage("Error opening Edit Product form: " + e.getMessage());
        }
    }
    // method for the archive button
    @FXML
    private void handleArchive() {
        Product selectedProduct = productTable.getSelectionModel().getSelectedItem();
        if (selectedProduct == null) {
            showErrorMessage("Please select a product to archive");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Archive Product");
        alert.setHeaderText("Archive Product: " + selectedProduct.getProductDescription());
        alert.setContentText("Are you sure you want to mark this product as inactive?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            archiveProduct(selectedProduct.getProductID());
        }
    }
    // method to delete a product
    private void archiveProduct(int productId) {
        String sql = "DELETE FROM Product WHERE ProductID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, productId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessMessage("Product successfully deleted");
                loadProducts(); // Refresh table
            } else {
                showErrorMessage("Failed to archive product");
            }

        } catch (SQLException e) {
            showErrorMessage("Database error: " + e.getMessage());
        }
    }
    // errors and success message
    private void showErrorMessage(String message) {
        statusLabel.setTextFill(Color.RED);
        statusLabel.setText("Error: " + message);
    }

    private void showSuccessMessage(String message) {
        statusLabel.setTextFill(Color.GREEN);
        statusLabel.setText(message);
    }
}