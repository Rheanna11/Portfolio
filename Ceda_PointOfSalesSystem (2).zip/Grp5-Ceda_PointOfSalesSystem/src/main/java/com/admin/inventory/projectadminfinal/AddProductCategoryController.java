package com.admin.inventory.projectadminfinal;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class AddProductCategoryController implements Initializable {

    @FXML private TextField categoryNameField;
    @FXML private TextField descriptionField;
    @FXML private Label statusLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (!validateInputs()) {
            return;
        }

        try {
            // Create a new product category object
            ProductCategory newCategory = new ProductCategory();
            newCategory.setCategoryName(categoryNameField.getText().trim());
            newCategory.setCategoryDescription(descriptionField.getText().trim());

            // Save the category to database referenced to the saveCategory method
            if (saveCategory(newCategory)) {
                showSuccessMessage("Category added successfully!");

                Thread.sleep(1000);
                closeForm(event);
            }

        } catch (Exception e) {
            showErrorMessage("Error: " + e.getMessage());
        }
    }
    // Validation to check if there are empty fields
    private boolean validateInputs() {

        if (categoryNameField.getText().trim().isEmpty()) {
            showErrorMessage("Category Name is required");
            categoryNameField.requestFocus();
            return false;
        }

        if (descriptionField.getText().trim().isEmpty()) {
            showErrorMessage("Description is required");
            descriptionField.requestFocus();
            return false;
        }
        // Checks if there is an existing category name
        if (categoryNameExists(categoryNameField.getText().trim())) {
            showErrorMessage("A category with this name already exists");
            categoryNameField.requestFocus();
            return false;
        }

        return true;
    }

    private boolean categoryNameExists(String categoryName) {
        String sql = "SELECT COUNT(*) FROM Category WHERE CategoryName = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, categoryName);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            showErrorMessage("Database error: " + e.getMessage());
        }

        return false;
    }
    // handles save button && database insertion
    private boolean saveCategory(ProductCategory category) {
        String sql = "INSERT INTO Category (CategoryName, Description) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, category.getCategoryName());
            stmt.setString(2, category.getCategoryDescription());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            showErrorMessage("Database error: " + e.getMessage());
            return false;
        }
    }
    //IF the user cancels the insertion of product category
    @FXML
    private void handleCancel(ActionEvent event) {
        closeForm(event);
    }

    private void closeForm(ActionEvent event) {
        // Get current stage and close it
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
    // error & success messages
    private void showErrorMessage(String message) {
        statusLabel.setTextFill(Color.RED);
        statusLabel.setText("Error: " + message);
    }

    private void showSuccessMessage(String message) {
        statusLabel.setTextFill(Color.GREEN);
        statusLabel.setText(message);
    }
}