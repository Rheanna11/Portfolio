package com.admin.inventory.projectadminfinal;

import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class SalesReportController implements Initializable {

    @FXML
    private DatePicker startDatePicker;
    @FXML
    private DatePicker endDatePicker;
    @FXML
    private ComboBox<EmployeeComboItem> employeeComboBox;
    @FXML
    private Button applyFilterBtn;
    @FXML
    private Button resetFilterBtn;
    @FXML
    private Label totalSalesLabel;
    @FXML
    private Label totalTransactionsLabel;
    @FXML
    private Label totalItemsSoldLabel;
    @FXML
    private TableView<SalesReportItem> salesTableView;
    @FXML
    private TableColumn<SalesReportItem, Integer> transactionIdColumn;
    @FXML
    private TableColumn<SalesReportItem, Date> transactionDateColumn;
    @FXML
    private TableColumn<SalesReportItem, Integer> employeeIdColumn;
    @FXML
    private TableColumn<SalesReportItem, Integer> salesLineIdColumn;
    @FXML
    private TableColumn<SalesReportItem, Integer> productIdColumn;
    @FXML
    private TableColumn<SalesReportItem, Integer> quantitySoldColumn;
    @FXML
    private TableColumn<SalesReportItem, Double> unitPriceColumn;
    @FXML
    private TableColumn<SalesReportItem, Double> totalLinePriceColumn;
    @FXML
    private Button printReportBtn;
    @FXML
    private Button exportExcelBtn;

    private ObservableList<SalesReportItem> salesData = FXCollections.observableArrayList();
    private ObservableList<EmployeeComboItem> employeesList = FXCollections.observableArrayList();
    private DatabaseConnection dbConnection;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        dbConnection = new DatabaseConnection();

        // Initialize date pickers with default values (current month)
        LocalDate now = LocalDate.now();
        startDatePicker.setValue(now.withDayOfMonth(1));
        endDatePicker.setValue(now);

        // Set up table columns
        transactionIdColumn.setCellValueFactory(new PropertyValueFactory<>("transactionId"));
        transactionDateColumn.setCellValueFactory(new PropertyValueFactory<>("transactionDate"));
        employeeIdColumn.setCellValueFactory(new PropertyValueFactory<>("employeeId"));
        salesLineIdColumn.setCellValueFactory(new PropertyValueFactory<>("salesLineId"));
        productIdColumn.setCellValueFactory(new PropertyValueFactory<>("productId"));
        quantitySoldColumn.setCellValueFactory(new PropertyValueFactory<>("quantitySold"));
        unitPriceColumn.setCellValueFactory(new PropertyValueFactory<>("unitPrice"));
        totalLinePriceColumn.setCellValueFactory(new PropertyValueFactory<>("totalLinePrice"));

        // Format currency columns (currently makes use of dollar sign)
        unitPriceColumn.setCellFactory(column -> new TableCell<SalesReportItem, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", price));
                }
            }
        });

        totalLinePriceColumn.setCellFactory(column -> new TableCell<SalesReportItem, Double>() {
            @Override
            protected void updateItem(Double total, boolean empty) {
                super.updateItem(total, empty);
                if (empty || total == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", total));
                }
            }
        });

        // Load employees for dropdown
        loadEmployees();

        // Add "All Employees" option
        employeesList.add(0, new EmployeeComboItem(0, "All Employees"));
        employeeComboBox.setItems(employeesList);
        employeeComboBox.getSelectionModel().selectFirst();

        // Load initial data
        loadSalesData();
    }

    private void loadEmployees() {
        String query = "SELECT EmployeeID, First_Name, Last_Name FROM Employee ORDER BY Last_Name, First_Name";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("EmployeeID");
                String firstName = rs.getString("First_Name");
                String lastName = rs.getString("Last_Name");
                employeesList.add(new EmployeeComboItem(id, lastName + ", " + firstName));
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Error loading employees: " + e.getMessage());
        }
    }

    private void loadSalesData() {
        salesData.clear();

        // Get filter values
        LocalDate startDate = startDatePicker.getValue();
        LocalDate endDate = endDatePicker.getValue();
        EmployeeComboItem selectedEmployee = employeeComboBox.getValue();

        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append("SELECT s.TransactionID, s.Transaction_Date, s.EmployeeID, ");
        queryBuilder.append("sl.Sales_LineID, sl.ProductID, sl.Quantity_Sold, sl.Unit_Price, sl.Total_Line_Price ");
        queryBuilder.append("FROM Sales s JOIN Sales_Line sl ON s.TransactionID = sl.TransactionID ");
        queryBuilder.append("WHERE s.Transaction_Date BETWEEN ? AND ? ");

        if (selectedEmployee != null && selectedEmployee.getId() > 0) {
            queryBuilder.append("AND s.EmployeeID = ? ");
        }

        queryBuilder.append("ORDER BY s.Transaction_Date DESC, s.TransactionID, sl.Sales_LineID");

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(queryBuilder.toString())) {

            pstmt.setDate(1, java.sql.Date.valueOf(startDate));
            pstmt.setDate(2, java.sql.Date.valueOf(endDate));

            if (selectedEmployee != null && selectedEmployee.getId() > 0) {
                pstmt.setInt(3, selectedEmployee.getId());
            }

            ResultSet rs = pstmt.executeQuery();

            double totalSales = 0;
            int totalItems = 0;
            Map<Integer, Boolean> uniqueTransactions = new HashMap<>();

            while (rs.next()) {
                int transactionId = rs.getInt("TransactionID");
                Date transactionDate = rs.getDate("Transaction_Date");
                int employeeId = rs.getInt("EmployeeID");
                int salesLineId = rs.getInt("Sales_LineID");
                int productId = rs.getInt("ProductID");
                int quantity = rs.getInt("Quantity_Sold");
                double unitPrice = rs.getDouble("Unit_Price");
                double totalLinePrice = rs.getDouble("Total_Line_Price");

                salesData.add(new SalesReportItem(transactionId, transactionDate, employeeId,
                        salesLineId, productId, quantity, unitPrice, totalLinePrice));

                totalSales += totalLinePrice;
                totalItems += quantity;
                uniqueTransactions.put(transactionId, true);
            }

            // Update summary labels
            totalSalesLabel.setText(String.format("$%.2f", totalSales));
            totalTransactionsLabel.setText(String.valueOf(uniqueTransactions.size()));
            totalItemsSoldLabel.setText(String.valueOf(totalItems));

            salesTableView.setItems(salesData);

        } catch (SQLException e) {
            showAlert("Database Error", "Error loading sales data: " + e.getMessage());
        }
    }

    @FXML
    private void handleApplyFilter(ActionEvent event) {
        loadSalesData();
    }

    @FXML
    private void handleResetFilter(ActionEvent event) {
        // Reset to current month
        LocalDate now = LocalDate.now();
        startDatePicker.setValue(now.withDayOfMonth(1));
        endDatePicker.setValue(now);

        // Reset employee selection
        employeeComboBox.getSelectionModel().selectFirst();

        // Reload data
        loadSalesData();
    }

    @FXML
    private void handlePrintReport(ActionEvent event) {
        // Print functionality would typically use JavaFX's printing API
        try {
            // Create a print job for the TableView
            javafx.print.PrinterJob job = javafx.print.PrinterJob.createPrinterJob();

            if (job != null && job.showPrintDialog(salesTableView.getScene().getWindow())) {
                boolean success = job.printPage(salesTableView);
                if (success) {
                    job.endJob();
                    showAlert("Print Success", "Report printed successfully!");
                } else {
                    showAlert("Print Error", "Printing failed.");
                }
            }
        } catch (Exception e) {
            showAlert("Print Error", "Error printing report: " + e.getMessage());
        }
    }

    @FXML
    private void handleExportExcel(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save CSV File");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        fileChooser.setInitialFileName("SalesReport_" +
                startDatePicker.getValue() + "_to_" + endDatePicker.getValue() + ".csv");

        File file = fileChooser.showSaveDialog(exportExcelBtn.getScene().getWindow());

        if (file != null) {
            exportToCSV(file);
        }
    }

    private void exportToCSV(File file) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            // Write CSV header
            writer.write("Transaction ID,Date,Employee ID,Sales Line ID,Product ID,Quantity,Unit Price,Line Total");
            writer.newLine();

            // Write data rows
            for (SalesReportItem item : salesData) {
                StringBuilder line = new StringBuilder();
                line.append(item.getTransactionId()).append(",");

                if (item.getTransactionDate() != null) {
                    line.append(item.getTransactionDate().toString());
                }
                line.append(",");

                line.append(item.getEmployeeId()).append(",");
                line.append(item.getSalesLineId()).append(",");
                line.append(item.getProductId()).append(",");
                line.append(item.getQuantitySold()).append(",");
                line.append(String.format("%.2f", item.getUnitPrice())).append(",");
                line.append(String.format("%.2f", item.getTotalLinePrice()));

                writer.write(line.toString());
                writer.newLine();
            }

            showAlert("Export Successful", "Report has been exported to: " + file.getAbsolutePath());

        } catch (IOException e) {
            showAlert("Export Error", "Error exporting to CSV: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Helper classes

    public static class SalesReportItem {
        private final IntegerProperty transactionId;
        private final ObjectProperty<Date> transactionDate;
        private final IntegerProperty employeeId;
        private final IntegerProperty salesLineId;
        private final IntegerProperty productId;
        private final IntegerProperty quantitySold;
        private final DoubleProperty unitPrice;
        private final DoubleProperty totalLinePrice;

        public SalesReportItem(int transactionId, Date transactionDate, int employeeId,
                               int salesLineId, int productId, int quantitySold,
                               double unitPrice, double totalLinePrice) {
            this.transactionId = new SimpleIntegerProperty(transactionId);
            this.transactionDate = new SimpleObjectProperty<>(transactionDate);
            this.employeeId = new SimpleIntegerProperty(employeeId);
            this.salesLineId = new SimpleIntegerProperty(salesLineId);
            this.productId = new SimpleIntegerProperty(productId);
            this.quantitySold = new SimpleIntegerProperty(quantitySold);
            this.unitPrice = new SimpleDoubleProperty(unitPrice);
            this.totalLinePrice = new SimpleDoubleProperty(totalLinePrice);
        }

        // Getters
        public int getTransactionId() { return transactionId.get(); }
        public Date getTransactionDate() { return transactionDate.get(); }
        public int getEmployeeId() { return employeeId.get(); }
        public int getSalesLineId() { return salesLineId.get(); }
        public int getProductId() { return productId.get(); }
        public int getQuantitySold() { return quantitySold.get(); }
        public double getUnitPrice() { return unitPrice.get(); }
        public double getTotalLinePrice() { return totalLinePrice.get(); }

        // Property getters
        public IntegerProperty transactionIdProperty() { return transactionId; }
        public ObjectProperty<Date> transactionDateProperty() { return transactionDate; }
        public IntegerProperty employeeIdProperty() { return employeeId; }
        public IntegerProperty salesLineIdProperty() { return salesLineId; }
        public IntegerProperty productIdProperty() { return productId; }
        public IntegerProperty quantitySoldProperty() { return quantitySold; }
        public DoubleProperty unitPriceProperty() { return unitPrice; }
        public DoubleProperty totalLinePriceProperty() { return totalLinePrice; }
    }

    public static class EmployeeComboItem {
        private final int id;
        private final String displayName;

        public EmployeeComboItem(int id, String displayName) {
            this.id = id;
            this.displayName = displayName;
        }

        public int getId() {
            return id;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }
}