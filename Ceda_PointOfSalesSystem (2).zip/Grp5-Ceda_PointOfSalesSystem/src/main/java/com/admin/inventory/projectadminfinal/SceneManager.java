package com.admin.inventory.projectadminfinal;


 // This is a utility class to manage loading of FXML scenes


import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


public class SceneManager {
    private final Map<String, Parent> sceneCache = new HashMap<>();

     //Gets a scene from the scene cache or loads it if not already loaded
     // @param fxmlPath The path to the FXML file
     // @return The Parent object for the scene

    public Parent getScene(String fxmlPath) {
        try {
            if (!sceneCache.containsKey(fxmlPath)) {
                // Add debug statement to see what's happening
                System.out.println("Loading: " + fxmlPath);

                // Get the resource URL
                var resourceUrl = getClass().getResource(fxmlPath);
                if (resourceUrl == null) {
                    throw new IOException("Resource not found: " + fxmlPath);
                }

                FXMLLoader loader = new FXMLLoader(resourceUrl);
                Parent root = loader.load();
                sceneCache.put(fxmlPath, root);
                return root;
            } else {
                return sceneCache.get(fxmlPath);
            }
        } catch (IOException e) {
            System.err.println("Error loading scene: " + e.getMessage());
            throw new RuntimeException("Failed to load " + fxmlPath, e);
        }
    }


    // Clears a scene from the cache, forcing it to reload next time it's requested

    public void clearCache(String fxmlPath) {
        sceneCache.remove(fxmlPath);
    }


    public void clearAllCache() {
        sceneCache.clear();
    }
}