package com.admin.inventory.projectadminfinal;

// THIS is a MODEL (container) for Employee to be used on editing and adding employees
// makes use of constructor and parameterized constructors
import java.time.LocalDate;

public class Employee {
    private int EmployeeID;
    private String firstName;
    private String middleName;
    private String lastName;
    private String sex;
    private LocalDate hireDate;
    private String employeeType;
    private String role;
    private String password;
    private String status;

    public Employee() {
    }

    public Employee(int EmployeeID, String firstName, String middleName, String lastName,
                    String sex, LocalDate hireDate, String employeeType, String role,
                    String password, String status) {
        this.EmployeeID = EmployeeID;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.sex = sex;
        this.hireDate = hireDate;
        this.employeeType = employeeType;
        this.role = role;
        this.password = password;
        this.status = status;
    }

    // the following are setters and getters

    public int getId() {
        return EmployeeID;
    }

    public void setId(int id) {
        this.EmployeeID = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    public String getEmployeeType() {
        return employeeType;
    }

    public void setEmployeeType(String employeeType) {
        this.employeeType = employeeType;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Helper method to get full name
    public String getFullName() {
        if (middleName != null && !middleName.isEmpty()) {
            return firstName + " " + middleName + " " + lastName;
        } else {
            return firstName + " " + lastName;
        }
    }
}