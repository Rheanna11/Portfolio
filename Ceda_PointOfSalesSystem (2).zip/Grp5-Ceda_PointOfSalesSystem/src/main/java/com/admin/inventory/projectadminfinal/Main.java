package com.admin.inventory.projectadminfinal;

//THIS WAS USED TO TEST THE ADMIN DASHBOARD DIRECTLY, KINDLY DISREGARD IF NOT NEEDED

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Objects;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/admin/inventory/projectadminfinal/AdminDashboard.fxml")));
        primaryStage.setTitle("Ceda Autoshop - Admin");        primaryStage.setScene(new Scene(root, 900, 700));
        primaryStage.setResizable(true);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}